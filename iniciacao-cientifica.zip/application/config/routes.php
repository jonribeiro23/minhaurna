<?php
defined('BASEPATH') OR exit('No direct script access allowed');

# Configuração
$route['default_controller'] = 'Login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

# Login
$route["externo/login"]      = "Login/login";
$route["externo/cadastro"]   = "Login/cadastro";
$route["externo/adicionar"]  = "Login/adicionar";
$route["externo/autenticar"]      = "Login/autenticar";

# Professores
$route["professores"]                = "Professor";
$route["professores/login"]          = "Professor/login";
$route["professores/cadastrar"]      = "Professor/cadastrar";
$route["professores/editar/(:num)"]  = "Professor/editar/$1";
$route["professores/excluir/(:num)"] = "Professor/excluir/$1";

# Datas
$route["datas"]        = "Datas";
$route["datas/salvar"] = "Datas/salvar";

# Teste
$route["datas/eventos/?(:any)?"] = "Datas/eventos/$1";
$route["datas/evento/(:num)"]    = "Datas/eventoNow/$1";
$route["teste/linha/?(:any)?"]    = "Teste/getLinhas/$1";

# Projetos

$route["projetos/adicionar"]               = "Projetos/teste";
$route["projetos/salvar"]                  = "Projetos/salvar";
$route["projetos/editar/(:num)"]           = "Projetos/editar/$1";
$route["projetos/deletar/(:num)"]          = "Projetos/deletar/$1";

$route["projetos/avaliar/(:num)"]          = "Projetos/avaliar/$1";
$route["projetos/ressalva/(:num)"]         = "Projetos/ressalva/$1";

$route["projetos/(:any)/ver/?(:num)?"]  = "Projetos/visualizar/$2";
//$route["projetos/ressalva/ver/(:num)"]     = "";
//$route["projetos/recusados/ver/(:num)"]    = "";
//$route["projetos/concluido/ver/(:num)"]    = "";

$route["projetos-proprios/?(:any)?"]                  = "Projetos";
$route["projetos-proprios/(:any)/listar/?(:num)?"]    = "Projetos";
$route["projetos/(:any)"]                             = "Projetos";
$route["projetos/(:any)/listar/?(:num)?"]             = "Projetos";



# Administradores
$route["administradores"]                  = "Administrador/listar";
$route["administradores/adicionar"]        = "Administrador/adicionar";
$route["administradores/salvar"]           = "Administrador/salvar";
// $route["administradores/editar"]        = "Administrador/editar";
$route["administradores/editar/?(:num)?"]  = "Administrador/editar/$1";
$route["administradores/deletar/?(:num)?"] = "Administrador/deletar/$1";
$route["administradores/listar/?(:num)?"]  = "Administrador/listar/$1";
$route["administradores/autores"]          = "Administrador/autores";
$route["administradores/autores-externos"] = "Administrador/autoresExternos";
$route["administradores/meus-autores"]     = "Administrador/meusAutores";

# Avaliadores
$route["avaliadores"]                 = "Avaliador/listar";
$route["avaliadores/adicionar"]       = "Avaliador/adicionar";
$route["avaliadores/editar"]          = "Avaliador/editar";
$route["avaliadores/editar/?(:num)?"] = "Avaliador/editar/$1";
$route["avaliadores/listar/?(:num)?"] = "Avaliador/listar/$1";
$route["avaliadores/deletar/?(:num)?"] = "Avaliador/deletar/$1";

# Orientadores
$route["orientadores"]                 = "Orientador/listar";
$route["orientadores/adicionar"]       = "Orientador/adicionar";
$route["orientadores/editar"]          = "Orientador/editar";
$route["orientadores/editar/(:num)"]   = "Orientador/editar/$1";
$route["orientadores/listar/?(:num)?"] = "Orientador/listar/$1";

# Autores
$route["autores"]                 = "Autor/listar";
$route["autores/?(:num)?"]        = "Autor/listar/$1";
$route["autores/form"]            = "Autor/preencheForm";
$route["autores/salvar"]          = "Autor/salvar";
$route["autores/salvar"]          = "Autor/salvar";
$route["autores/salvar/?(:num)?"]          = "Autor/salvar/$1";
$route["autores/editar"]          = "Autor/editar";
$route["autores/editar/(:num)"]   = "Autor/editar/$1";
$route["autores/adicionar"]       = "Autor/adicionar";
$route["autores/listar/?(:num)?"] = "Autor/listar/$1";
$route["autores/deletar/?(:num)?"] = "Autor/deletar/$1";
$route["autores/todos"]   = "Autor/todos_autores";
