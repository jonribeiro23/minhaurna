<?php

namespace Cloudinary\Api;

/**
 * Class BadRequest
 * @package Cloudinary\Api
 */
class BadRequest extends Error
{
}
