<html lang="pt-br">
<script src="<?= base_url('public/js/libraries/jquery-2.2.4.min.js')?>"></script>

<head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <!--Depêndencias-->
    <link rel="stylesheet" href="../public/css/cadastro-login.css?v=<?=time();?>">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">

    <script src="../public/js/valida-login.js"></script>
    <script src="https://kit.fontawesome.com/72c6380c9f.js"></script>

</head>

<style>

</style>

<body>

    <main>
        
        <?php $this->load->view('partials/views/mensagem') ?>
        
        <div class="container">

            <form class="style-1" method="post" action="<?= base_url('Login/autenticar') ?>" onSubmit="return ( verifica() )" name="form-envia">
                <!-- <div class="mobile-form"> -->
                    <div class="title">
                        <p>Login</p>
                    </div>

                    <div class="input1">
                        <input type="email" name="email" id="email" onblur="checarEmail();" required size="30" placeholder="E-mail">
                        <img class="input-icon" src="../public/img/icons/user.svg"></i>
                    </div>

                    <div class="input2">
                        <input type="password" name="senha" id="senha" minlength="6" required size="30" placeholder="Senha">
                        <img class="input-icon" src="../public/img/icons/key.svg"></i>
                    </div>

                    <div class="grupo-botoes">
                        <div class="button-flex">
                            <a class="voltar" href="https://iniciacao-cientifica.herokuapp.com">
                                <input id="cancelar" name="button" value="Voltar" class="button">
                            </a>
                        </div>
                        <div class="button-flex">
                            <input type="submit" id="submit" name="button" value="Login" class="button">
                        </div>
                    </div>
                <!-- </div> -->
            </form>
        </div>
    </main>
    <!--<div>Icons made by <a href="https://www.freepik.com/?__hstc=57440181.0864f3a4066b2215a4aef466fd41fb7b.1559707393588.1559707393588.1559707393588.1&__hssc=57440181.1.1559707393589&__hsfp=244919210" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" 			    title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 			    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>-->
</body>


</html>
