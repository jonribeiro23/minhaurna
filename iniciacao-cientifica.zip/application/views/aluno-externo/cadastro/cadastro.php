<html lang="pt-br">

<head>
    <title>Cadastro</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <!--Depêndencias-->
    <link rel="stylesheet" href="../public/css/cadastro.css?v=<?=time();?>">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">

    <script src="../public/js/valida-cadastro.js"></script>

</head>

<body>

    <main>
        <div class="container">
            <!--<div class="container-web">-->
                <form class="form-ic style-1" method="post" action="<?= base_url('externo/adicionar') ?>" onSubmit="return ( verifica() )" name="form-envia">
                    <!-- <div class="scroll"> -->
                        <div class="title">
                            <p>Cadastro</p>
                        </div>
                        
                        <div class="input1">
                            <input type="text" name="nome" id="nome" required size="26" placeholder="Nome">
                            <img class="input-icon" src="../public/img/icons/user.svg"></i>
                        </div>
                        
                        <div class="input2">
                            <input type="text" name="area" id="area" required size="26" placeholder="Área">
                            <img class="input-icon" src="../public/img/icons/"></i>
                        </div>  

                        <div class="input3">
                            <input type="text" name="cpf" id="cpf" minlength="11" required size="26" placeholder="CPF">
                            <img class="input-icon" src="../public/img/icons/cpf.svg"></i>
                        </div>

                        <div class="input4">
                            <input type="text" name="nivel" id="nivel" minlength="11" required size="26" placeholder="Nível">
                            <img class="input-icon" src="../public/img/icons/"></i>
                        </div>
                        
                        <div class="input5">
                            <input type="email" name="email" id="email" required size="26" onblur="checarEmail();" placeholder="E-mail">
                            <img class="input-icon" src="../public/img/icons/mail.svg"></i>
                        </div>
                      
                        <div class="input6">
                            <input type="password" name="senha" id="senha" minlength="6" required size="30" placeholder="Senha">
                            <img class="input-icon" src="../public/img/icons/key.svg"></i>
                        </div>
                        
                      
                        <div class="input7">
                            <input type="password" name="senha2" id="senha2" minlength="6" required size="30" placeholder="Confirmar senha">
                            <img class="input-icon" src="../public/img/icons/key.svg"></i>
                        </div>

                        <div class="input8">
                            <input type="text" name="lattes" id="lattes" required size="26" placeholder="Lattes">
                            <img class="input-icon" src="../public/img/icons/"></i>
                        </div>

                        <div class="input9">
                            <input type="text" name="titulacao" id="titulacao" required size="26" placeholder="Titulação">
                            <img class="input-icon" src="../public/img/icons/"></i>
                        </div>
                        
                        <div class="grupo-botoes">
                            <div class="button-flex">
                                <a class="voltar" href="https://iniciacao-cientifica.herokuapp.com">
                                    <input id="cancelar" name="button" value="Voltar" class="button">
                                </a>
                            </div>
                            <div class="button-flex">
                                <input type="submit" id="submit" name="button" value="Enviar" class="button">
                            </div>
                        </div>
                        
                    </form>
                <!--</div>-->
            </div>
    </main>
    <!--<div>Icons made by <a href="https://www.freepik.com/?__hstc=57440181.0864f3a4066b2215a4aef466fd41fb7b.1559707393588.1559707393588.1559707393588.1&__hssc=57440181.1.1559707393589&__hsfp=244919210" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" 			    title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" 			    title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>-->
</body>


</html>
