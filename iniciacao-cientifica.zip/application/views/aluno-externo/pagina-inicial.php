<!Doctype html>

<html lang="pt-br">

<head>
	<title>Iniciação Cientifica</title>
	<meta charset="utf-8">

	<link href="public/css/pag-inicial.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">

	<script src="https://kit.fontawesome.com/72c6380c9f.js"></script>
</head>

<body>
		
	<main class="container">
		<h1>olá!</h1>
		<h4>Seja Bem Vindo, vamos começar</h4>

	<div class="icons">
			
		<div class="desktop">
			<a href="<?= base_url('externo/login') ?>"><i class="fas fa-user"></i></a>
		</div>
			
		<div class="desktop">
			<a href="<?= base_url('externo/cadastro') ?>"><i class="fas fa-user-plus"></i></a>
		</div>

	</div>	
	
	<div id="position-button">		
		<div>
			<a href="<?= base_url('externo/login') ?>"><button type="button" class="login">Login 
				<picture>
					<source media="(min-width: 992px)" srcset="https://img.icons8.com/ios-glyphs/25/FFFFFF/long-arrow-right.png">
		        	<img src="https://img.icons8.com/ios-glyphs/50/FFFFFF/long-arrow-right.png" alt="user">
		        </picture>	
			</button></a>
		</div>

		<div>
			<a href="<?= base_url('externo/cadastro') ?>"><button type="button" class="cadastro">
				<picture>
					<source media="(min-width: 992px)" srcset="https://img.icons8.com/ios-glyphs/25/733DBF/long-arrow-left.png">
					<img src="https://img.icons8.com/ios-glyphs/50/733DBF/long-arrow-left.png" alt="user-plus">
				</picture>
			Cadastro</button></a>
		</div>
	</div>	
		
	</main>	
		<div class="foto-efeito">
			<img src="public/img/efeito-mobile.png" alt="efeito estetico ondas">
		</div>
	


</body>

</html>