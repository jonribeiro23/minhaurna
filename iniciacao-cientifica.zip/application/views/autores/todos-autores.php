	<link href="<?= base_url('public/css/todos-autores.css') ?>" rel="stylesheet" type="text/css">
			<div class="cabecalho-tabela">
				<h1>Autores</h1>		
				<a href="<?= base_url('autores/adicionar')?>"><i class="fas fa-plus"></i>
				cadastrar</a>
			</div>
			
		<div class="submenu">	
	    	<ul id="submenu">
	      		<li><a href="<?= base_url('autores')?>"> Meus autores</a></li>
	      		<li id="menu-active"><a href="<?= base_url('autores/todos')?>">Todos os autores</a></li>
	    	</ul>
		</div>	
		
		<!--<div class="container-filtro">-->
			<div class=filtro>
				<i class="fas fa-filter"></i>
				<h2>Filtro</h2>
				<form action="">
					<input class="pesquisa" type="text" placeholder="Digite o nome aqui...">
					
					<span id="box_icone_busca">
        				<i id="icone_busca" class="fa fa-search"></i>
    				</span>
				</form>
			</div>
		<!--</div>-->
		<!-- até aqui -->

		<?php $this->load->view('partials/views/mensagem') ?>
		<div class="caption-1">
			<p>Nome</p>
			<p>CPF</p>
			<p>E-mail</p>
			<p>Instituição</p>
			<p>Lattes</p>
			<p>Linha de pesquisa</p>				
			<p>Ações</p>	
		</div>
		<?php if ($autores) { ?>
			<?php foreach ($autores as $a) { ?>
				<div class="list">
					<p><?= $a['nm_Autor'] ?></p>
					<p><?= $a['ds_Cpf'] ?></p>
					<p><?= $a['ds_Email'] ?></p>
					<p><?= $a['nm_Curso'] ?></p>
					<p>www.meulattessupershow.com.br</p>
					<p>Lorem ipsum</p>
					<a href="<?= base_url('autores/editar/').$a["cd_Autor"] ?>">Editar</a>
					<a href="<?= base_url('autores/deletar/').$a["cd_Autor"] ?>" class="icons-actions"><i class="fas fa-trash-alt"></i></a>
				</div>	
			<?php } ?>
		<?php } ?>

		<?php echo $paginacao; ?>		
