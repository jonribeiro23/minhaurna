<link href="<?= base_url('public/css/painel-adm-form.css') ?>" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 

<script>
	$(document).ready(()=>{
		$("input[name='cpf']").blur(() => {
			var cpf = $('#cpf').val();
			$.ajax({
				url : "<?= base_url('autores/form') ?>",
				type: "POST",
				dataType: "JSON",
				data: {query: cpf},
				success: function(data){
					console.log(data);
					$('#nome').val(data[0].nm_Usuario);
					$('#email').val(data[0].ds_Email);
				}
			});
		})
	})
</script>

	<?php $this->load->view('partials/views/mensagem') ?>

	<div class="cabecalho-tabela">
		<h1>Cadastrar<span class="secondary"> | Autores</span></h1>

	</div>
	<div class=" container">
		<form class="style-1" action="<?= base_url('autores/salvar') ?>" method="post">
			<div class="campo">
				<label for="cpf">CPF</label>
				<input type="text" id="cpf" name="cpf" placeholder="Digite aqui..." value="">
			</div>
			<div class="campo">
				<label for="nome">Nome</label>
				<input type="text" id="nome" name="nome" placeholder="Digite aqui..." value="">
			</div>
		
			<div class="campo">
				<label for="email">E-mail</label>
				<input type="text" id="email" name="email" placeholder="Digite aqui..." value="">
			</div>
			<div class="campo instituicao">
				<label for="area">Instituição</label>
				<select>
						<option value="fatec rubens lara">Fatec Rubens Lara</option>
				</select>
			</div>

			<div class="campo instituicao">
				<label for="area">Curso</label>
				<select name="curso">
					<?php foreach ($cursos as $c) { ?>
						<option value="<?= $c['nm_Curso'] ?>"><?= $c['nm_Curso'] ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="campo linha">
				<label for="linha">Linha de pesquisa</label>
				<select name="linha">
					<?php foreach ($linhas as $d) {?>
						<option value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Linha']) ?></option>
					<?php } ?>
				</select>
			</div>

			<div class="campo">
				<label for="lattes">Lattes</label>
				<input type="text" id="lattes" name="lattes" placeholder="Digite aqui..." value="">
			</div>
			<div class="grupo-botoes">
				<button id="cancelar" type="reset" name="canelar">Cancelar</button>
				<button id="cadastrar" type="submit" name="cadastrar">Cadastrar</button>
			</div>
		</form>
	<div class=" container">

	<!-- <div class="result">
		
	</div> -->