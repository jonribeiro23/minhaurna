<link href="<?= base_url('public/css/painel-adm-form.css') ?>" rel="stylesheet">


	<?php $this->load->view('partials/views/mensagem') ?>

	<div class="cabecalho-tabela">
		<h1>Editar<span class="secondary"> | Autores</span></h1>

	</div>
	<div class=" container">
		<form class="style-1" action="<?= base_url('autores/salvar/').$autor['cd_Autor'] ?>" method="post">
			<div class="campo">
				<label for="cpf">CPF</label>
				<input type="text" id="cpf" name="cpf" placeholder="Digite aqui..." value="<?= $autor['ds_Cpf'] ?>">
			</div>
			<div class="campo">
				<label for="nome">Nome</label>
				<input type="text" id="nome" name="nome" placeholder="Digite aqui..." value="<?= $autor['nm_Autor'] ?>">
			</div>
		
			<div class="campo">
				<label for="email">E-mail</label>
				<input type="text" id="email" name="email" placeholder="Digite aqui..." value="<?= $autor['ds_Email'] ?>">
			</div>
			<div class="campo instituicao">
				<label for="area">Instituição</label>
				<select>
						<option value="fatec rubens lara">Fatec Rubens Lara</option>
				</select>
			</div>

			<div class="campo instituicao">
				<label for="area">Curso</label>
				<select name="curso">
					<?php foreach ($cursos as $c) { ?>
						<option <?= $autor['nm_Curso'] == $c['nm_Curso'] ? 'selected' : null ?> value="<?= $c['nm_Curso'] ?>"><?= $c['nm_Curso'] ?></option>
					<?php } ?>
				</select>
			</div>
			<!-- <div class="campo linha">
				<label for="linha">Linha de pesquisa</label>
				<select name="linha">
					<?php foreach ($linhas as $d) {?>
						<option <?= $autor[''] == $d['cd_Numero'] ? 'selected' : null ?> value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Linha']) ?></option>
					<?php } ?>
				</select>
			</div> -->

			<div class="campo">
				<label for="lattes">Lattes</label>
				<input type="text" id="lattes" name="lattes" placeholder="Digite aqui..." value="<?= isset($autor['ds_Lattes'])?$autor['ds_Lattes']:null ?>">
			</div>
			<div class="grupo-botoes">
				<button id="cancelar" type="reset">Cancelar</button>
				<button id="cadastrar" type="submit">Salvar</button>
			</div>
		</form>
	<div class=" container">

	<!-- <div class="result">
		
	</div> -->