<link href="<?= base_url('public/css/painel-adm-form.css') ?>" rel="stylesheet">
	<div class="cabecalho-tabela">
		<h1>Cadastrar<span class="secondary"> | Avaliadores</span></h1>
		<?php //var_dump($dados) ?>
	</div>
	
	<div class=" container">
    	<form method="post" class="style-1" action="<?= base_url('avaliadores/adicionar') ?>" >
    				<div class="campo">
    					<label for="nome">Nome</label>
    					<input type="text" id="nome" name="nome" placeholder="Digite aqui..." value="">
    				</div>
    				<div class="campo">
    					<label for="cpf">CPF</label>
    					<input type="text" id="cpf" name="cpf" placeholder="Digite aqui..." value="">
    				</div>
    				
    				<div class="campo">
    					<label for="email">E-mail</label>
    					<input type="text" id="email" name="email" placeholder="Digite aqui..." value="">
                    </div>	
                    
                    <div class="campo titulacao">
    					<label for="titulacao">Titulaçao</label>
    					<input type="text" id="titulacao" name="titulacao" placeholder="Digite aqui..." value="">
    				</div>

    				<div class="campo area">
    					<label for="area">Grande Area</label>
    					<select name="area">
    						<?php foreach ($areas as $d) {?>
    							<option value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Area']) ?></option>
    						<?php } ?>
    					</select>
    				</div>
    				
    				<div class="campo linha">
    					<label for="linha">Linha de pesquisa</label>
    					<select name="linha">
    						<?php foreach ($linhas as $d) {?>
    							<option value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Linha']) ?></option>
    						<?php } ?>
    					</select>
    				</div>
					<div class="campo">
            			<label for="celular">Celular</label>
            			<input type="text" id="celular" name="celular" placeholder="Digite aqui..." value="">
       				 </div>
                <div class="campo">
        			<label>Senha</label>
            		<input type="password" name="senha">
				</div>
				<div class="campo">
        			<label>Confirmar senha</label>
            		<input type="password" name="csenha">
        		</div>
    				<div class="campo">
    					<label>Acesso</label>
    					<div class="checkbox">
    						<input type="checkbox" id="checkbox_3" name="acesso3" placeholder="Digite aqui..." value="avaliador">
    						<label for="checkbox_3">Avaliador</label>
    					</div>
    				</div>
    			
    		<div class="grupo-botoes">
    			<button id="cancelar" type="reset" name="canelar">CANCELAR</button>
    			<button id="cadastrar" type="submit" name="cadastrar">CADASTRAR</button>
    		</div>
    	</form>
	</div>

