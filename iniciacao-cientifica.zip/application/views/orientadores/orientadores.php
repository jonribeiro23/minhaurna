<link href="<?= base_url() ?>public/css/orientadores.css" rel="stylesheet">
			<div class="cabecalho-tabela">
				<h1>Orientadores</h1>		
				<a href="<?= base_url('orientadores/adicionar') ?>"><i class="fas fa-plus"></i>
				cadastrar</a>
			</div>	

			<div class="caption-1">
					<p>Nome</p>
					<p>CPF</p>
					<p>E-mail</p>
					<!-- <p>Grande área(cnp)</p> -->
					<p>Ações</p>
			</div>	
			
			<?php if ($orientadores) { ?>
				<?php foreach ($orientadores as $a) { ?>
					
						<?php if ($a['nm_Nivel']=='orientador') { ?>
							<div class="list">
								<p class="item1"><?= $a['nm_Usuario'] ?></p>
								<p class="item2"><?= $a['ds_Cpf'] ?></p>
								<p class="item3"><?= $a['ds_Email'] ?></p>
								<!-- <p class="item4"><?= $area['0']['nm_Area'];?></p> -->
								
							

								<a href="<?= base_url("orientadores/editar/$a[cd_Usuario]") ?>" class="icons-actions"><i class="fas fa-edit"></i></a>
								<a href="<?= base_url("orientadores/deletar/$a[cd_Usuario]") ?>" class="icons-actions"><i class="fas fa-trash-alt"></i></a>
							</div>	
						<?php } ?>

				<?php } ?>
<?php } ?>

<?php echo $paginacao; ?>
<!-- 
		<div id="scroll">	
			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p>Lorem ipsum</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Instituição</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>Lorem ipsum</p>
					</div>		
				</div>
			</div>	
						
			<div class="list1">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p>Lorem ipsum</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Instituição</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>Lorem ipsum</p>
					</div>		
				</div>
			</div>	
			
			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p>Lorem ipsum</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Instituição</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>Lorem ipsum</p>
					</div>		
				</div>
			</div>	

			<div class="list1">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p>Lorem ipsum</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Instituição</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>Lorem ipsum</p>
					</div>		
				</div>
			</div>	


			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p>Lorem ipsum</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Instituição</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>Lorem ipsum</p>
					</div>		
				</div>
			</div>		 -->


				<!-- <div class="buttons">
					<a class="active button">1</a>
					<a class="button">2</a>
					<a class="button">3</a>
					<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
				</div>	
		</div>	 -->	