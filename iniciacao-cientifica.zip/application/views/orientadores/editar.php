<link href="<?= base_url('public/css/painel-adm-form.css') ?>" rel="stylesheet">
	<div class="cabecalho-tabela">
		<h1>Editar<span class="secondary"> | Orientadores</span></h1>

	</div>
	
	<div class="container">
    	<form class="style-1" action="#" method="post">
    		<div class="campo">
    			<label for="nome">Nome</label>
    			<input type="text" id="nome" name="nome" placeholder="Digite aqui..." value="">
    		</div>
    		<div class="campo">
    			<label for="cpf">CPF</label>
    			<input type="text" id="cpf" name="cpf" placeholder="Digite aqui..." value="">
    		</div>
    		
    		<div class="campo">
    			<label for="email">E-mail</label>
    			<input type="text" id="email" name="email" placeholder="Digite aqui..." value="">
    		</div>
    		<div class="campo instituicao">
                <label for="area">Instituição</label>
                <select disabled>
                        <option></option>
                </select>
            </div>
    
    		<div class="campo linha">
    			<label for="linha">Linha de pesquisa</label>
    			<select disabled>
    					<option></option>
    			</select>
    		</div>
    		
    		<div class="campo">
    			<label for="lattes">Lattes</label>
    			<input type="text" id="lattes" name="lattes" placeholder="Digite aqui..." value="">
    		</div>
    
    		<div class="grupo-botoes">
    			<button id="cancelar" type="reset" name="canelar">CANCELAR</button>
    			<button id="cadastrar" type="submit" name="cadastrar">SALVAR</button>
    		</div>
    	</form>
    </div>