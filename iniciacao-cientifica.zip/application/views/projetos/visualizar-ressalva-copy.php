<!-- <!Doctype html>

<html lang="pt-br">

<head>
	<title>Painel de Administradores</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no">
	
    <link href="<?= base_url('public/css/vizualizar-ressalva.css') ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://kit.fontawesome.com/72c6380c9f.js"></script>

	<script>
	    $(document).ready(function(){
		    $(".fa-info-circle").click(function(){
		        $(this).next().toggle("fast");
		    });
		});
	</script>
</head>

<body>
	
	<header></header>
	
	<div class="container">
		<nav>
			<ul>
				<li>
					<a href="https://iniciacao-cientifica-anabalan.c9users.io/iniciacaoCientifica/admin">
						<i class="fas fa-users-cog"></i>
						Administradores
					</a>
				</li>
				<li>
					<a href="https://iniciacao-cientifica-anabalan.c9users.io/iniciacaoCientifica/avaliadores">
						<i class="fas fa-users-cog"></i>
						Avaliadores
					</a>
				</li>
				<li>
					<a href="https://iniciacao-cientifica-anabalan.c9users.io/iniciacaoCientifica/orientadores">
						<i class="fas fa-users-cog"></i>
						Orientadores
					</a>
				</li>
				<li>
					<a href="">
						<i class="fas fa-users-cog"></i>
						Autores
					</a>
				</li>
				<li>
					<a href="">
						<i class="fas fa-users-cog"></i>
						Projetos
					</a>
				</li>
				<li class="link-active">
					<a href="">
						<i class="fas fa-users-cog"></i>
						Projetos próprios
					</a>
				</li>
				<li>
					<a href="">
						<i class="fas fa-users-cog"></i>
						Período de inscrição
					</a>
				</li>
			</ul>
		</nav> 

		<div class="table-list">
		-->
		<div class="cabecalho-tabela">
				<h1>Projetos <span>| RESSALVA</span></h1>		
				<button><i class="fas fa-plus"></i>
				cadastrar</button>
			</div>
			<div class="container-info-projeto">
				<div class="infos1">
					<form>
						<p>Título</p>
							<input type="text" placeholder="Pipipi popopo" name="titulo-projeto">
						<p>Projeto</p>
							<input type="text" class="campo-relatorio1" value="relatorio_legalzao.pdf" name="titulo-projeto">
					</form>
				</div>
				<div class="infos2">
					<form>
						<p>Autor</p>
							<select name="autor">
								<option value="volvo">Fulano</option>
								<option value="saab">Ciclano</option>
							</select>
						<p>Linha de Pesquisa</p>
							<input type="text" placeholder="Pipipi popopo" name="projeto">
					</form>
				</div>
			</div>
			
			<div class="container-avaliadores">
				<div class="avaliador1">
					<p>Avaliador 1</p>
					<textarea name="comentario-avaliador" rows="10" cols="84">
					</textarea>
				</div>
				<div class="avaliador2">
					<p>Avaliador 2</p>
					<textarea name="comentario-avaliador" rows="10" cols="84">
					</textarea>
				</div>
			</div>

			<div class="container-relatorio">
				<form>
					<p>Relatório</p>
					<input type="text" class="campo-relatorio2" value="relatorio_top.pdf" name="titulo-projeto">
				</form>
			</div>

			<div class="container-btn">
					<button class="botoes-fim-pag">Cancelar</button>
					<button class="botoes-fim-pag btn-clicked">Salvar</button>
			</div>
		</div>

	</div>
<!-- 
	<div class="efeito-desktop">
		<img src="public/img/efeito-desktop-i.png" alt="efeito-desktop" width="300" height="150">
	</div>		

		
</body>
</html>	 -->
