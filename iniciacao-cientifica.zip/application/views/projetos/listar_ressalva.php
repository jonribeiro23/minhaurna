<link href="<?= base_url('public/css/ressalva.css') ?>" rel="stylesheet">
<div class="cabecalho-tabela">
				<h1>Projetos</h1>	
				<h3>| Ressalva</h3>	
			</div>	

			<div class="submenu">	
				<ul id="submenu">
					<li><a href="<?= base_url('projetos/avaliadores') ?>"> Definir avaliadores</a></li>
					<li><a href="<?= base_url('projetos/pendentes') ?>">Pendentes a avaliação</a></li>
					<li><a href="<?= base_url('projetos/avaliar') ?>">Avaliar</a></li>
					<li id="menu-active"><a href="<?= base_url('projetos/ressalva') ?>">Ressalva</a></li>
					<li><a href="<?= base_url('projetos/recusados') ?>">Recusados</a></li>
					<li><a href="<?= base_url('projetos/concluido') ?>">Concluído</a></li>
				</ul>
			</div>

    		<div class="caption">
				<p>Nome do Projeto</p>	
				<p>Linha de pesquisa</p>		
				<p>Ações</p>	
			</div>	

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<i class="fas fa-info-circle"></i>
			</div>

			 <div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<i class="fas fa-info-circle"></i>
			</div>
				
			<div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="buttons">
				<?= $this->pagination->create_links() ?>

				<!--
				<a class="active button">1</a>
				<a class="button">2</a>
				<a class="button">3</a>
				<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
				-->
			</div>