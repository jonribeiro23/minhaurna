		<link href="<?= base_url('public/css/projeto-proprio-andamento.css') ?>" rel="stylesheet" type="text/css">
			<div class="cabecalho-tabela">
				<h1>Projetos próprios <span>| Ressalva</span></h1>		
				<a href=""><i class="fas fa-plus"></i>
				cadastrar</a>
			</div>
			
			<div class="submenu">	
	    		<ul id="submenu">
	      			<li id="menu-active"><a href="<?= base_url('projetos-proprios/andamento') ?>">Andamento</a></li>
	      			<li><a href="<?= base_url('projetos-proprios/concluido') ?>">Concluído</a></li>
	    		</ul>
    		</div>	

		<div class="caption-1">
			<p>Título</p>
			<p>Linha de pesquisa</p>
			<p>Autor</p>
			<p>Ações</p>
		</div>	

			<div class="list">
				<p class="item1">Lorem Ipsum</p>
				<p class="item2">Lorem Ipsum</p>
				<p class="item3">Lorem Ipsum</p>
                <a href="" class="icons-actions"><i class="fas fa-info-circle"></i></a>	
			</div>	
			
			<div class="buttons">
				<?= $this->pagination->create_links() ?>

				
				<!-- <a class="active button">1</a>
				<a class="button">2</a>
				<a class="button">3</a>
				<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
				 -->
			</div>	
