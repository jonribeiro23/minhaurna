drop <link href="<?= base_url() ?>public/css/projetos.css" rel="stylesheet">
<div class="cabecalho-tabela">
				<h1>Projetos</h1>	
				<h3>| Definir avaliador</h3>	
				<!-- EXIBINDO FLASHDATA POR MOTIVO DE TESTES -->
				<p><?= $this->session->flashdata('alert-success') ?> </p>
				<p><?= $this->session->flashdata('alert-danger') ?> </p>
				<!--  -->
			</div>	

			<div class="submenu">	
				<ul id="submenu">
					<li id="menu-active"><a href="<?= base_url('projetos/avaliadores') ?>"> Definir avaliadores</a></li>
					<li><a href="<?= base_url('projetos/pendentes') ?>">Pendentes a avaliação</a></li>
					<li><a href="<?= base_url('projetos/avaliar') ?>">Avaliar</a></li>
					<li><a href="<?= base_url('projetos/ressalva') ?>">Ressalva</a></li>
					<li><a href="<?= base_url('projetos/recusados') ?>">Recusados</a></li>
					<li><a href="<?= base_url('projetos/concluido') ?>">Concluído</a></li>
				</ul>
			</div>	

    		<div class="caption">
				<p>Nome do projeto</p>	
				<p>Área</p>		
				<p>Ações</p>	
			</div>
			
			  <div class="modal">
			   <div class="modal-wrap">
			    <div class="modal-box">
			      <!-- Dynamic Section -->
				    <form id="checkbox" name="checkbox" method="post" action="#">
				    	<h1>Avaliadores</h1>
				    	<h3>Selecione os avaliadores</h3>
				    	<div>	
							<input type="checkbox" id="avaliador" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>				
				    	  <div>	
							<input type="checkbox" id="avaliador2" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador2" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				          <div>	
							<input type="checkbox" id="avaliador3" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador3" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				          <div>	
							<input type="checkbox" id="avaliador4" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador4" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				         <div>	
							<input type="checkbox" id="avaliador5" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador5" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				          <div>	
							<input type="checkbox" id="avaliador6" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador6" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				          <div>	
							<input type="checkbox" id="avaliador7" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador7" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				        <div>	
							<input type="checkbox" id="avaliador8" class="checkbox-custom" name="avaliador" onclick="Avaliador(this)">
						    <label for="avaliador8" class="checkbox-custom-label">Ruy Cordeiro Accioly</label>
						</div>	
				 

						<div class="buttons-modal">
					      	<button class="modal-close">Cancelar</button>
					     	<button type="submit" name="salvar">Salvar</button>
				        </div>
				    </form>
				    <!-- End of Dynamic Section -->
			    </div>
			   </div>
			 </div>

			 <?php foreach ($projetos as $projeto) { ?>

				<div class="list">
					<p><?= $projeto['cd_Projeto'] ?>-<?= $projeto['nm_Titulo'] ?></p>
					<p><?= $projeto['ds_Url'] ?></p>
					<a class="modal-open" href="#"><i class="fas fa-plus-circle"></i></a>
					<i class="fas fa-info-circle"></i>
				</div>
			 <?php } ?>

				<div class="buttons">
					<?= $this->pagination->create_links() ?>

					<!--
					Não tenho como aproveitar o estilo dos botões, já que estão vinculados
					ao elemento 'button'
					<a class="active button">1</a>
					<a class="button">2</a>
					<a class="button">3</a>
					<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
					-->
				</div>	