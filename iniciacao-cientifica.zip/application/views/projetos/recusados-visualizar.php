<link href="<?= base_url('public/css/visualizar-projeto1.css') ?>" rel="stylesheet">
<div class="cabecalho-tabela">
	<h1>Projetos <span class="secondary">| Recusados / Visualizar projeto</span></h1>		
</div>	

<div class="container">
	<div class="content style-1">
		<div class="linha">
			<p>Título</p>
			<p>Autor</p>
		</div>
		
		<div class="linha">
			<p class="secondary">Alpacas e seus dons de encantamento</p>
			<p class="secondary">Savior Of Alpaca</p>
		</div>
		
		<div class="linha">
			<p>Projeto (clique para fazer o download)</p>
			<p>Linha de pesquisa</p>
		</div>
		
		<div class="linha">
			<div class="secondary"><button>alpacas_sao_demais.pdf<i class="fas fa-download fa-lg"></i></button></div>
			<p class="secondary">Alpacamento</p>
		</div>
		
		<hr>
		
		<h2>RESSALVA</h2>
		<textarea rows="10" placeholder="Digite aqui..."></textarea>
		
		<div class="grupo-botoes">
			<button id="cancelar" type="reset" name="canelar">CANCELAR</button>
			<button id="salvar" type="submit" name="salvar">SALVAR</button>
		</div>
	</div>
</div>