	<link href="<?= base_url('public/css/projeto-listar-avaliar.css') ?>" rel="stylesheet">
	<script>
	    $(document).ready(function(){
		    $(".fa-info-circle").click(function(){
		        $(this).next().toggle("fast");
		    });
		});
	</script>
	
			<div class="cabecalho-tabela">
				<h1>Projetos</h1>	
				<h3>| Avaliar</h3>	
				<!-- EXIBINDO FLASHDATA POR MOTIVO DE TESTES -->
				<p><?= $this->session->flashdata('alert-success') ?> </p>
				<p><?= $this->session->flashdata('alert-danger') ?> </p>
				<!--  -->
			</div>	

			<div class="submenu">	
	    		<ul id="submenu">
	      			<li><a href="<?= base_url('projetos/avaliadores') ?>"> Definir avaliadores</a></li>
	      			<li><a href="<?= base_url('projetos/pendentes') ?>">Pendentes a avaliação</a></li>
	      			<li id="menu-active"><a href="<?= base_url('projetos/avaliar') ?>">Avaliar</a></li>
	      			<li><a href="<?= base_url('projetos/ressalva') ?>">Ressalva</a></li>
	      			<li><a href="<?= base_url('projetos/recusados') ?>">Recusados</a></li>
	      			<li><a href="<?= base_url('projetos/concluido') ?>">Concluído</a></li>
	    		</ul>
    		</div>	

    		<div class="caption">
				<p>Título</p>
				<p>Linha de Pesquisa</p>
				<p>Autor</p>
				<p>Orientador</p>
				<p>Ações</p>
			</div>	

			<div class="list roxo">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<button class="avaliar"><i class="fas fa-check-circle fa-lg"></i>Avaliar</button>
			</div>

			 <div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<button class="avaliar"><i class="fas fa-check-circle fa-lg"></i>Avaliar</button>
			</div>

			<div class="list roxo">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<button class="avaliar"><i class="fas fa-check-circle fa-lg"></i>Avaliar</button>
			</div>
				
			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<button class="avaliar"><i class="fas fa-check-circle fa-lg"></i>Avaliar</button>
			</div>	

			<div class="buttons">
				<?= $this->pagination->create_links() ?>
				<!-- 
				<button class="active">1</button>
				<button>2</button>
				<button>3</button>
				<button><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></button> 
				-->
			</div>	