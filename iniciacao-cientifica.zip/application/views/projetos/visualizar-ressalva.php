<style>

</style>


<link href="<?= base_url('public/css/visualizar-ressalva.css') ?>" rel="stylesheet">
<div class="cabecalho-tabela">
	<h1>Projetos <span class="secondary">| Ressalva</span></h1>		
	<!-- <button><i class="fas fa-plus"></i>
	cadastrar</button> -->
</div>

<div class="container">
	<div class="content style-1">
		<div class="linha">
			<p>Título</p>
			<p>Autor</p>
		</div>

		<div class="linha">
			<input disabled class="secondary" type="text" placeholder="Digite aqui..." name="titulo-projeto">
			<select disabled class="secondary disabled-select" name="autor">
				<option value="fulano">Fulano</option>
				<option value="ciclano">Ciclano</option>
			</select>
		</div>

		<div class="linha">
			<p>Projeto</p>
			<p>Linha de Pesquisa</p>
		</div>

		<div class="linha">
			<div class="secondary disabled" id=""><button disabled>relatorio_projeto.pdf<i class="fas fa-upload fa-lg"></i></button></div>
			<input disabled class="secondary" type="text" placeholder="Digite aqui..." name="linha">
		</div>

		<hr>

		<div class="linha">
			<p>Avaliador 1</p>
			<p>Avaliador 2</p>
		</div>

		<div class="linha">
			<textarea disabled class="secondary" name="comentario-avaliador" rows="10" placeholder="Digite aqui...">
			</textarea>
			<textarea disabled class="secondary" name="comentario-avaliador" rows="10" placeholder="Digite aqui...">
			</textarea>
		</div>

		<hr>

		<div class="linha">
			<p>Relatório (x meses)</p>
		</div>

		<div class="linha">
			<div class="secondary"><button>relatorio_projeto.pdf<i class="fas fa-upload fa-lg"></i></button></div>
		</div>
		
		<div class="linha">
			<p>Relatório (x meses)</p>
		</div>

		<div class="linha">
			<div class="secondary"><button>relatorio_projeto.pdf<i class="fas fa-upload fa-lg"></i></button></div>
		</div>

		<div class="grupo-botoes">
			<button id="cancelar" type="reset" name="canelar">CANCELAR</button>
			<button id="salvar" type="submit" name="salvar">SALVAR</button>
		</div>
	</div>

</div>