	<link href="public/css/painel-adm.css" rel="stylesheet">
			<div class="cabecalho-tabela">
				<h1>Administradores</h1>		
				<button><i class="fas fa-plus"></i>
				cadastrar</button>
			</div>	

		<div class="caption-1">
			<p>Nome</p>
			<p>CPF</p>
			<p>E-mail</p>
			<p>Área</p>
			<p>Nível</p>
			<p>Ações</p>
		</div>	

			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Titulação</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>minhatitulação</p>
					</div>		
				</div>
			</div>	
						
			<div class="list1">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Titulação</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>minhatitulação</p>
					</div>		
				</div>
			</div>	
			
			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Titulação</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>minhatitulação</p>
					</div>		
				</div>
			</div>	

			<div class="list1">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Titulação</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>minhatitulação</p>
					</div>		
				</div>
			</div>	

			<div class="list">
				<p>Ruy Cordeiro Accioly</p>
				<p>483.346.718-65</p>
				<p>ruy.cordeiro@gmail.com</p>
				<p>Logística</p>
				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
				<div class="rowContent">
					<div class="caption">
						<p>Celular</p>
						<p>Lattes</p>			
						<p>Titulação</p>
					</div>
					<div class="content">
						<p>13 98120-5325</p>	
						<p>www.meulattessupershow.com.br</p>				
						<p>minhatitulação</p>
					</div>		
				</div>
			</div>		


				<div class="buttons">
					<button class="active">1</button>
					<button>2</button>
					<button>3</button>
					<button><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></button>
				</div>	

		