<link href="<?= base_url() ?>public/css/concluido-comlink.css" rel="stylesheet">            
            <div class="cabecalho-tabela">
				<h1>Projetos próprios</h1>	
			</div>	

			<div class="submenu">	
	    		<ul id="submenu">
	      			<li><a href="">Andamento</a></li>
	      			<li id="menu-active"><a href="">Concluído</a></li>
	    		</ul>
    		</div>	

    		<!--<div class="container-filtro">-->
			<div class="filtro">
				<i class="fas fa-filter"></i>
				<h2>Filtro</h2>
				  <select id="tipo-projeto" class="tipo-projeto">
				    	<option value="Publicado" selected>Publicado</option>
				    	<option value="Pendente">Pendente</option>
				  </select>
			</div>
			<!--</div>-->

    		<div class="caption">
				<p>Título</p>	
				<p>Linha de pesquisa</p>
				<p>Autor</p>
				<p>Link</p>		
				<p>Ações</p>	
			</div>	

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>www.revistaincrivel.com.br</p>
				<i class="fas fa-info-circle"></i>
			</div>

			 <div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>www.revistaincrivel.com.br</p>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>www.revistaincrivel.com.br</p>
				<i class="fas fa-info-circle"></i>
			</div>
				
			<div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>www.revistaincrivel.com.br</p>
				<i class="fas fa-info-circle"></i>
			</div>

				<div class="buttons">
					<a class="active button">1</a>
					<a class="button">2</a>
					<a class="button">3</a>
					<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
				</div>	