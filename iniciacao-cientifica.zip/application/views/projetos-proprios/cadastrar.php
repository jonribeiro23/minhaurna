<link href="<?= base_url('public/css/cadastrar-projeto.css') ?>" rel="stylesheet">
<div class="cabecalho-tabela">
	<h1>Cadastrar<span class="secondary"> | Projeto</span></h1>	
	<!-- EXIBINDO FLASHDATA POR MOTIVO DE TESTES -->
	<p><?= $this->session->flashdata('alert-success') ?> </p>
	<p><?= $this->session->flashdata('alert-danger') ?> </p>
	<!--  -->
</div>	

<div class="container">
		<?= form_open_multipart('projetos/salvar', 'class="style-1"'); ?>
    	<div class="campo">
    		<label for="titulo">Título</label>
    		<input type="text" id="titulo" name="titulo" placeholder="Digite aqui..." value="">
    	</div>
    	<div class="campo">
    		<label for="autor">Autor</label>
    		<select name="autor">
    	        <option value="" selected disabled hidden>Selecione da lista</option>
    			<?php foreach ($autores as $a) { ?>
                    <option value="<?= $a[0]['cd_Autor'] ?>"><?= $a[0]['nm_Autor'] ?></option>
                <?php } ?>
    		</select>
    	</div>
    	<!--
    	<div class="campo">
    		<label for="projeto">Projeto</label>
    		<button>nomedoarquivo.pdf<i class="fas fa-file-upload fa-lg"></i></button>
    	</div>
    	-->
    	<div class="campo">
    		<label for="projeto">Projeto</label>
				<!-- <button class="arquivo-secondary">Selecionar arquivo<i class="fas fa-file-upload fa-lg"></i></button> -->
				<!-- button não é a mesma coisa que input type='file' -->
				<input id="projeto" type='file' name='projeto' accept="application/pdf">
    	</div>
    	<div class="campo">
    		<label for="linha">Linha de pesquisa</label>
    		<input type="text" id="linha" name="linha" placeholder="Digite aqui..." value="">
    	</div>
    
        <div class="grupo-botoes">
    			<button id="cancelar" type="reset" name="canelar">CANCELAR</button>
					<button id="cadastrar" type="submit" name="cadastrar">CADASTRAR</button>
    		</div>
    </form>
</div>

