<link href="<?= base_url('public/css/concluido-semlink.css') ?>" rel="stylesheet">
            <div class="cabecalho-tabela">
				<h1>Projetos próprios</h1>	
			</div>	

			<div class="submenu">	
	    		<ul id="submenu">
	      			<li><a href="<?= base_url('projetos-proprios/andamento') ?>">Andamento</a></li>
	      			<li id="menu-active"><a href="<?= base_url('projetos-proprios/concluido') ?>">Concluído</a></li>
	    		</ul>
    		</div>	

    		<!--<div class="container-filtro">-->
			<div class="filtro">
				<i class="fas fa-filter"></i>
				<h2>Filtro</h2>
				  <select id="tipo-projeto" class="tipo-projeto">
				    	<option value="Publicado">Publicado</option>
				    	<option value="Pendente" selected>Pendente</option>
				  </select>
			</div>
			<!--</div>-->

    		<div class="caption">
				<p>Título</p>	
				<p>Linha de pesquisa</p>
				<p>Autor</p>
				<p>Link</p>		
				<p>Ações</p>	
			</div>	

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<a class="modal-open" href="#"><i class="fas fa-plus-circle"></i>Adicionar</a>
				<i class="fas fa-info-circle"></i>
			</div>
			<div class="modal">
			   <div class="modal-wrap">
			    <div class="modal-box">
			      <!-- Dynamic Section -->
				    <form id="adc-link" name="adc-link" method="post" action="#">
				    	
				    	<div id="input-link">
				    		<label for="url-type-input">URL</label>
  							<input type="url" id="url-type-input" class="link">
				    	</div>		
						   	
						<div class="buttons-modal">
					      	<button class="modal-close">Cancelar</button>
					     	<button type="submit" name="salvar">Salvar</button>
				        </div>
				    </form>
				    <!-- End of Dynamic Section -->
			    </div>
			   </div>
			 </div>

			<div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<a class="modal-open" href="#"><i class="fas fa-plus-circle"></i>Adicionar</a>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="list">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<a class="modal-open" href="#"><i class="fas fa-plus-circle"></i>Adicionar</a>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="list1">
				<p>Lorem ipsum Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<p>Lorem ipsum</p>
				<a class="modal-open" href="#"><i class="fas fa-plus-circle"></i>Adicionar</a>
				<i class="fas fa-info-circle"></i>
			</div>

			<div class="buttons">
				<?= $this->pagination->create_links() ?>

				<!--
				<a class="active button">1</a>
				<a class="button">2</a>
				<a class="button">3</a>
				<a class="button"><img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim"></a>
				-->
			</div>	