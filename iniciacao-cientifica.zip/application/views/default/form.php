<?php
  $flash = $this->session->flashdata();
  $mensagens = isset($mensagens) ? $mensagens : null;
  $existeAlerta = isset($flash["alert-success"]) || isset($flash["alert-warning"]);

  if (isset($mensagens) || $existeAlerta) {
    $this->load->view("partials/views/mensagem", [
      "flash"     => $flash,
      "mensagens" => $mensagens
    ]);
  }
?>

<form
  action="<?= base_url($action) ?>"
  method="<?= !isset($post) || (isset($post) && $post) ? "post" : "get" ?>"
>
  <fieldset class="main-fieldset">
    <?php $this->load->view($view); ?>
  </fieldset>
  
  <fieldset class="grupo-botoes">
    <button id="cancelar" type="reset">Cancelar</button>
    <button id="cadastrar" type="submit">Cadastrar</button>
  </fieldset>
</form>