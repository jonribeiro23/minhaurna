<div class="campo">
  <label for="nome">Nome</label>
  
  <input
    id="nome"
    type="text"
    name="nome"
    placeholder="João da Silva"
    value="<?= isset($form) && isset($form["nome"]) ? $form["nome"] : null ?>"
  >
</div>

<div class="campo">
  <label for="email">Email</label>
  
  <input
    id="email"
    name="email"
    type="email"
    placeholder="usuario@email.com.br"
    value="<?= isset($form) && isset($form["email"]) ? $form["email"] : null ?>"
  >
</div>

<div class="campo">
  <label for="senha">Senha</label>
  
  <input
    id="senha"
    name="senha"
    type="password"
    placeholder="*****"
    value="<?= isset($form) && isset($form["senha"]) ? $form["senha"] : null ?>"
  >
</div>

<div class="campo">
  <label for="confirmacao-senha">Confirmação da senha</label>
  
  <input
    type="password"
    placeholder="*****"
    id="confirmacao-senha"
    name="confirmacao-senha"
    value="<?= isset($form) && isset($form["confirmacao-senha"]) ? $form["confirmacao-senha"] : null ?>"
  >
</div>

<div class="campo">
  <label for="lattes">Lattes</label>
  
  <input
    type="url"
    id="lattes"
    name="lattes"
    placeholder="https://www.site.com.br/exemplo"
    value="<?= isset($form) && isset($form["lattes"]) ? $form["lattes"] : null ?>"
  >
</div>

<div class="campo">
  <label>Titulação</label>
  
  <select name="titulacao">
    <option value="dr">Doutor</option>
    <option value="mr">Mestre</option>
  </select>
</div>

<div class="campo">
  <label for="celular">Celular</label>
  
  <input
    type="tel"
    id="celular"
    name="celular"
    placeholder="(00) 0 0000-0000"
    value="<?= isset($form) && isset($form["celular"]) ? $form["celular"] : null ?>"
  >
</div>

<div class="campo">
  <label for="cpf">CPF</label>
  
  <input
    id="cpf"
    name="cpf"
    type="text"
    placeholder="000.000.000-00"
    value="<?= isset($form) && isset($form["cpf"]) ? $form["cpf"] : null ?>"
  >
</div>