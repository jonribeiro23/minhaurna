<h1>Listagem de Professores</h1>

<?php
  if (count($professores)) {?>
    <table>
      <thead>
        <tr>
          <td>Nome</td>
          <td>Email</td>
          <td>Titulação</td>
          <td>Editar</td>
        </tr>
      </thead>

      <tbody>
        <?php
          foreach ($professores as $professor) {?>
            <tr>
              <td><?= $professor->nome ?></td>
              <td><?= $professor->email ?></td>
              <td><?= $professor->titulacao ?></td>

              <td>
                <a
                  title="Editar Professor(a)"
                  href="<?= base_url("professores/editar/$professor->id") ?>"
                >
                  Editar
                </a>
              </td>
            </tr><?php
          }
        ?>
      </tbody>
    </table><?php
  }
  else {?>
    <h2>Nenhum resultado a ser exibido</h2><?php
  }
?>