<!Doctype html>
<html lang="pt-br">
    <head>
    	<title>Painel de Orientadores</title>
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, user-scalable=no">
    
    	<link href="public/css/painel-adm.css" rel="stylesheet">
    	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">
    
    	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    	<script src="https://kit.fontawesome.com/72c6380c9f.js"></script>
    
    	<script>
    	    $(document).ready(function(){
    		    $(".fa-info-circle").click(function(){
    		        $(this).next().toggle("fast");
    		    });
    		});
    	</script>
    </head>
    
    <body>
	    <header></header>
	
    	    <div class="container">
    
    		<div class="table-list">
    			<div class="cabecalho-tabela">
    				<h1>Orientadores</h1>		
    				<button><i class="fas fa-plus"></i>
    				cadastrar</button>
    			</div>	
    
    		<div class="caption-1">
    			<p>Nome</p>
    			<p>CPF</p>
    			<p>E-mail</p>
    			<p>Área</p>
    			<p>Nível</p>
    			<p>Ações</p>
    		</div>	
    
    			<div class="list">
    				<p>Ruy Cordeiro Accioly</p>
    				<p>483.346.718-65</p>
    				<p>ruy.cordeiro@gmail.com</p>
    				<p>Logística</p>
    				<p class="alinhar">3</p>
    					<i class="fas fa-edit"></i>
    					<i class="fas fa-trash-alt"></i>	
    					<i class="fas fa-info-circle"></i>		
    				<div class="rowContent">
    					<div class="caption">
    						<p>Celular</p>
    						<p>Lattes</p>			
    						<p>Titulação</p>
    					</div>
    					<div class="content">
    						<p>13 98120-5325</p>	
    						<p>www.meulattessupershow.com.br</p>				
    						<p>minhatitulação</p>
    					</div>		
    				</div>
    			</div>	
    						
    			<div class="list1">
    				<p>Ruy Cordeiro Accioly</p>
    				<p>483.346.718-65</p>
    				<p>ruy.cordeiro@gmail.com</p>
    				<p>Logística</p>
    				<p class="alinhar">3</p>
    					<i class="fas fa-edit"></i>
    					<i class="fas fa-trash-alt"></i>	
    					<i class="fas fa-info-circle"></i>		
    				<div class="rowContent">
    					<div class="caption">
    						<p>Celular</p>
    						<p>Lattes</p>			
    						<p>Titulação</p>
    					</div>
    					<div class="content">
    						<p>13 98120-5325</p>	
    						<p>www.meulattessupershow.com.br</p>				
    						<p>minhatitulação</p>
    					</div>		
    				</div>
    			</div>	
    			
    			<div class="list">
    				<p>Ruy Cordeiro Accioly</p>
    				<p>483.346.718-65</p>
    				<p>ruy.cordeiro@gmail.com</p>
    				<p>Logística</p>
    				<p class="alinhar">3</p>
    					<i class="fas fa-edit"></i>
    					<i class="fas fa-trash-alt"></i>	
    					<i class="fas fa-info-circle"></i>		
    				<div class="rowContent">
    					<div class="caption">
    						<p>Celular</p>
    						<p>Lattes</p>			
    						<p>Titulação</p>
    					</div>
    					<div class="content">
    						<p>13 98120-5325</p>	
    						<p>www.meulattessupershow.com.br</p>				
    						<p>minhatitulação</p>
    					</div>		
    				</div>
    			</div>	
    
    			<div class="list1">
    				<p>Ruy Cordeiro Accioly</p>
    				<p>483.346.718-65</p>
    				<p>ruy.cordeiro@gmail.com</p>
    				<p>Logística</p>
    				<p class="alinhar">3</p>
    					<i class="fas fa-edit"></i>
    					<i class="fas fa-trash-alt"></i>	
    					<i class="fas fa-info-circle"></i>		
    				<div class="rowContent">
    					<div class="caption">
    						<p>Celular</p>
    						<p>Lattes</p>			
    						<p>Titulação</p>
    					</div>
    					<div class="content">
    						<p>13 98120-5325</p>	
    						<p>www.meulattessupershow.com.br</p>				
    						<p>minhatitulação</p>
    					</div>		
    				</div>
    			</div>	
    
    			<div class="list">
    				<p>Ruy Cordeiro Accioly</p>
    				<p>483.346.718-65</p>
    				<p>ruy.cordeiro@gmail.com</p>
    				<p>Logística</p>
    				<p class="alinhar">3</p>
					<i class="fas fa-edit"></i>
					<i class="fas fa-trash-alt"></i>	
					<i class="fas fa-info-circle"></i>		
    				
    				<div class="rowContent">
    					<div class="caption">
    						<p>Celular</p>
    						<p>Lattes</p>			
    						<p>Titulação</p>
    					</div>
    					
    					<div class="content">
    						<p>13 98120-5325</p>	
    						<p>www.meulattessupershow.com.br</p>				
    						<p>minhatitulação</p>
    					</div>		
    				</div>
    			</div>
    			
				<div class="buttons">
					<button class="active">1</button>
					<button>2</button>
					<button>3</button>
					
					<button>
					    <img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim">
					</button>
				</div>
    		</div>
	    </div>
	
    	<div class="efeito-desktop">
    		<img src="public/img/efeito-desktop-i.png" alt="efeito-desktop" width="300" height="150">
    	</div>	
    </body>
</html>