<nav>
  <ul>
    <?php
      $areas = [
        "Administradores",
        "Avaliadores",
        "Orientadores",
        "Autores",
        "Projetos",
        "Projetos Próprios",
        "Período de Inscrição",
      ];
      
      # Não há a necessidade de inserir o prefixo
      # 'fa-' do Font Awesome devido ao fato de que
      # este prefixo será fixo e imutável.
      $icones = [
        "default" => "users-cog",
        "Administradores" => "users-cog",
        "Avaliadores" => "flag-usa",
        "Orientadores" => "chalkboard-teacher",
        "Autores" => "feather-alt",
        "Projetos" => "book",
        "Projetos Próprios" => "address-book",
        "Período de Inscrição" => "clock",
      ];

      # Por padrão, o link da área será o nome da mesma
      # transformada em letras minúsculas, com espaçamento
      # entre hífens (-) e sem acentuação. Caso seja neces-
      # sário uma URL que seja diferente da gerada automati-
      # camente, basta inserir no array abaixo.
      $links = [
        //"Projetos Próprios" => "projetos/proprios",
      ];
      
      # Instância do CodeIgniter
      $this->CI = &get_instance();

      $this->load->helper('url');
      $this->load->library('acentos');
      
      # Página atual
      $atual = $this->uri->segment(1);

      foreach ($areas as $area) {
        $link = $this->CI->acentos->remover($area);
        $link = str_replace(" ", "-", strtolower($link));
        $link = isset($links[$area]) ? $links[$area] : $link;
        
        $icone = isset($icones[$area]) ? $icones[$area] : $icones["default"];
        $classe = $link === $atual ? 'link-active' : null;?>
        
        <li class="<?= $classe ?>">
          <a href="<?= base_url($link) ?>">
            <i class="fas fa-<?= $icone ?>"></i>
            <?= $area ?>
          </a>
        </li><?php
      }
    ?>
  </ul>
</nav>