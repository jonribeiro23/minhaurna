<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Iniciação Científica</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no">

		<link href= <?= base_url('public/css/base.css') ?> rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700,900" rel="stylesheet">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://kit.fontawesome.com/72c6380c9f.js"></script>
		<script src="<?= base_url('public/js/partials/listagens.js') ?>"></script>
	</head>

	<body>
		<header></header>
		
		<div class="efeito-desktop">
			<img src="<?= base_url('public/img/efeito-desktop-i.png') ?>" alt="efeito-desktop" width="300" height="150">
		</div>
	
		<div class="container">
			<?php $this->load->view("partials/menu") ?>

			<div class="table-list">
			