<form method='post' action='datas/salvar'>
    <label for="">Evento</label>
    <select name="evento" id="">
        <?php foreach($datas as $d){ ?>
            <option value="<?= $d['cd_Evento']?>"> <?= $d['nm_Evento'] ?> </option>
        <?php } ?>
    </select>
    <br>
    <label for="">Data Inicial</label>
    <br>
    <input type="date" name="data-inicial"/>
    <br>
    <label for="">Data Final</label>
    <br>
    <input type="date" name="data-final"/>
    <br>
    <input type="submit" value="Submit"/>
</form>