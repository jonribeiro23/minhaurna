<link href="<?= base_url('public/css/painel-adm-form.css') ?>" rel="stylesheet">
	<div class="cabecalho-tabela">
		<h1>Editar<span class="secondary"> | Administradores</span></h1>
	
	</div>

	<div class="container">
    	<form class="style-1" method="post" action="<?php base_url('administradores/salvar')?>" >
			
			<div class="campo">
				<label for="nome">Nome</label>
				<input type="text" id="nome" name="nome" placeholder="" value="<?php echo($dados['nome']) ?>">
			</div>

			<div class="campo">
				<label for="cpf">CPF</label>
				<input type="text" id="cpf" name="cpf" placeholder="" value="<?php echo($dados['cpf']) ?>">
			</div>

			<div class="campo">
				<label for="email">E-mail</label>
				<input type="text" id="email" name="email" placeholder="" value="<?php echo($dados['email']); ?>">
            </div>	
            

            <div class="campo">
				<label for="titulacao">Titulaçao</label>
				<input type="text" id="celular" name="celular" placeholder="" value="<?php echo($dados['titulacao']); ?>">
			</div>

			
            <div class="campo">
				<label for="celular">Celular</label>
				<input type="text" id="celular" name="celular" placeholder="" value="<?php echo($dados['celular']); ?>">
			</div>

			<div class="campo">
                <label for="lattes">Lattes</label>
                <input type="text" id="lattes" name="lattes" placeholder="Digite aqui..." value="<?php echo($dados['lattes']); ?>">
            </div>
			

			<div class="campo area">
    					<label for="area">Grande Area</label>
    					<select name="area">
						<option value="<?= $area['0']['cd_Area'] ?>"><?= utf8_decode($area['0']['nm_Area']) ?></option>

    						<?php foreach ($areas as $d) {?>
    							<option value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Area']) ?></option>
    						<?php } ?>
    					</select>
    		</div>
    			
			<div class="campo linha">
    					<label for="linha">Linha de pesquisa</label>
    					<select name="linha">
    						<?php foreach ($linhas as $d) {?>
    							<option value="<?= $d['cd_Numero'] ?>"><?= utf8_decode($d['nm_Linha']) ?></option>
    						<?php } ?>
    					</select>
			</div>

			<div class="campo">
				<label>Acesso</label>
				<div class="checkbox">
					<input type="checkbox" id="checkbox_1" name="acesso" placeholder="Digite aqui..." value="master">
					<label for="checkbox_1">Master</label>
			    </div>
				<div class="checkbox">
					<input type="checkbox" id="checkbox_2" name="acesso" placeholder="Digite aqui..." value="orientador">
					<label for="checkbox_2">Orientador</label>
				</div>
				<div class="checkbox">
					<input type="checkbox" id="checkbox_3" name="acesso" placeholder="Digite aqui..." value="avaliador">
					<label for="checkbox_3">Avaliador</label>
				</div>
			</div>
    			
    		<div class="grupo-botoes">
    			<button id="cancelar" type="reset" name="cancelar">CANCELAR</button>
    			<button id="cadastrar" type="submit" name="cadastrar" href="base_url('avaliadores/adicionar')">SALVAR</button>
    		</div>
    	</form>
    </div>
