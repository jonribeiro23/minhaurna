<link href="<?= base_url() ?>public/css/painel-adm.css" rel="stylesheet">
			<div class="cabecalho-tabela">
				<h1>Administradores</h1>		
				<a href="<?= base_url('administradores/adicionar') ?>"><i class="fas fa-plus"></i>
				cadastrar</a>
			</div>	

			<div class="caption-1">
	<p>Nome</p>
	<p>CPF</p>
	<p>Email</p>
	<!-- <p>Curso</p> -->
	<p>Nivel</p>
	<p>Açoes</p>
</div>
<?php if ($administradores) { ?>
	<?php foreach ($administradores as $a) { ?>
		<div class="list">
			<p class="item1"><?= $a['nm_Usuario'] ?></p>
			<p class="item2"><?= $a['ds_Cpf'] ?></p>
			<p class="item3"><?= $a['ds_Email']?></p>
			<p class="item4"><?= $a['nm_Nivel']?></p>

            
            <!--<a href="<?= base_url('autores/editar/').$a["cd_Autor"] ?>"><img src="https://image.flaticon.com/icons/svg/61/61456.svg" style="cursor: pointer;width: 1.2%;margin-left: 8%;"><!--</a>-->
			<!--<a href="<?= base_url('autores/deletar/').$a["cd_Autor"] ?>"><i class="fas fa-trash-alt"></i></a>-->

			<!--<p class="item4"><?= $area['0']['nm_Area']?></p> -->

			

			<a href="<?= base_url("administradores/editar/$a[cd_Usuario]") ?>" class="icons-actions"><i class="fas fa-edit"></i></a>
			<a href="<?= base_url("administradores/deletar/$a[cd_Usuario]") ?>" class="icons-actions"><i class="fas fa-trash-alt"></i></a>

			<!-- <i class="fas fa-edit"></i>
			<i class="fas fa-trash-alt"></i> -->
		</div>	
	<?php } ?>
<?php } ?>

<?php echo $paginacao; ?>

		
			</div>		

		