<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

// class Orientador extends Controle_acesso {
// 	public function __construct() {
//     parent::__construct();
//     $this->verificarPermissoes(['master']);
//     $this->load->model('professor_model', 'professor');

// 	}
	
// 	public function listar($inicio = 0) {
//       $this->load->view('partials/base-topo');
//       $this->load->view('orientadores/orientadores');
//       $this->load->view('partials/base-fim');
//   }
  
//   public function adicionar() {

//     $form = $this->input->post();

//     //Se o post existir
//     if ($form) {
//       $this->salvar($form);
//     } else {
//       $this->load->view('partials/base-topo');
//       $this->load->view('orientadores/adicionar');
//       $this->load->view('partials/base-fim');
//     }
//   }

  
//   public function editar($id = null) {

//     //Busca o registro pelo id
//     $orientador = $this->professor->buscar($id);

//     //Checa se é orientador
//     $isOrientador = false;
//     if (!empty($orientador)) {
//       foreach ($orientador['niveis'] as $nivel){
//         if ($nivel['cdNivel'] == 2) $isOrientador = true;
//       }
//     }
    
//     //Se não encontrar ou não for orientador
//     if (empty($orientador) || !$isOrientador) {
//       $this->session->set_flashdata('alert-warning', 'Orientador não encontrado');
//       return redirect('orientadores');
//     }

//     $form = $this->input->post();

//     //Se o post existir
//     if ($form) {
//       $this->salvar($form, true, $id, $orientador);
//     } else {
//       $this->load->view('partials/base-topo');
//       $this->load->view('orientadores/editar', [
// 				'form'    => $orientador,
// 			]);
//       $this->load->view('partials/base-fim');
//     }
//   }

//   public function salvar($form, $editar = false, $id = null, $orientador = null){

//     //Verifica valores únicos
//     verificarValores($form, $editar, $orientador);
    
//     //Edita ou cadastra os valores do form, possívelmente retornando
//     //o id em caso de inserção e false em caso de falha
//     $ultimo_id = $editar 
//       ? $this->professor->editar($form, $id)
//       : $this->professor->cadastrar($form);
    
//     //Se a inserção/edição funcionar
//     if ($ultimo_id != false){
//       //Se foi editar
//       if ($editar){
//         //Limpa as linhas para substituir depois
//         $this->professor->excluirUsuarioLinhas($id);
//         //Troca o que estiver na variável pelo id do editado
//         $ultimo_id = $id;
//       }

//       //Se for cadastro, adiciona o nível orientador
//       if (!$editar) $this->professor->cadastrarUsuarioNivel($ultimo_id, 2);
      
//       //Cadastra 3 possíveis linhas
//       if (!empty($form['linha1'])) $this->professor->cadastrarUsuarioLinha($ultimo_id, $form['linha1']);
//       if (!empty($form['linha2'])) $this->professor->cadastrarUsuarioLinha($ultimo_id, $form['linha2']);
//       if (!empty($form['linha3'])) $this->professor->cadastrarUsuarioLinha($ultimo_id, $form['linha3']);

//       $this->session->set_flashdata("alert-success", "Sucesso ao salvar o orientador");
//     }
//     else {
//       $this->session->set_flashdata("alert-warning", "Erro ao salvar o orientador");
//     }

//     return redirect(base_url("orientadores"));
//   }

//   public function verificarValores($form, $editar, $orientador = null) {
//     # Valores a serem verificados
//     $colunas = [
//       "cpf"   => "ds_Cpf",
//       "email" => "ds_Email",
//       "nome"  => "nm_Usuario"
//     ];
    
//     //Passa por cada coluna
//     foreach ($colunas as $valor => $coluna) {
//       //Se houver um registro original (em caso de edição) checa
//       //se essa coluna especifica foi alterada
//       $alterado = !empty($orientador) 
//         ? ($form[$valor] != $orientador[$coluna])
//         : true
//       ;

//       //Checa se já existe outro registro com o valor dessa coluna
//       $registro = $this->professor->existeRegistro($coluna, $form[$valor]);
      
//       //Se já existe esse valor e foi uma coluna alterada
//       if ($alterado && $registro) {
//         return $this->form($editar, $form, [
//           "erro" => "O valor $valor já está em uso"
//         ], $orientador);
//       }
//     }
//   }

//   public function validar($editar = false, $form) {
//     $this->load->library('form_validation');

//     $this->form_validation->set_rules("cpf", "CPF", "required");
//     $this->form_validation->set_rules("nome", "Nome", "required");
//     $this->form_validation->set_rules("email", "Email", "required");

//     if (!$editar || !empty($form["senha"])) {
//       $this->form_validation->set_rules("senha", "Senha", "required");
//       $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
//     }

//     $this->form_validation->set_rules("lattes", "Lattes", "required");
//     $this->form_validation->set_rules("celular", "Celular", "required");
//     $this->form_validation->set_rules("titulacao", "Titulação", "required");

//     return $this->form_validation->run();
//   }

//   public function form($editar = false, $dados = null, $mensagens = null, $dados2 = null) {
//     $acao    = $editar ? "editar" : "adicionar";
//     $caminho = "orientadores/$acao";

//     return $this->load->view($caminho, [
//       "form"      => empty($dados2) ? $dados : $dados2,
//       "mensagens" => $mensagens,
//     ]);
//   }


// }



defined('BASEPATH') OR exit('No direct script access allowed');

class Orientador extends Controle_acesso {
  public function __construct() {
    parent::__construct();
  $this->verificarPermissoes(['master']);
  $this->load->library('Cpf');
    $this->load->library('Criptografar');
    $this->load->library('form_validation');
    
    
    $this->load->model('Usuario_model', 'user_model');
    $this->load->model('Areas_Linhas_model', 'al_model');
    $this->load->model('Orientador_model', 'orientador');
    $this->load->model('Professor_Model', 'prof_model');  
  }
  
  public function listar($inicio = 0) {
    //Paginacao
    $config = array(
      "base_url" => base_url('orientadores/listar/'),
      "per_page" => 5,
      "num_links" => 2,
      "uri_segment" => 2,
      "total_rows" => $this->user_model->ContarLinhas("3"),
      "full_tag_open" => "<div class='buttons'>",
      "full_tag_close" => "</div>",
      "first_link" => FALSE,
      "last_link" => FALSE,
      "first_tag_open" => "<button>",
      "first_tag_close" => "</button>",
      "prev_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-left.png' alt='seta-fim'>",
      "prev_tag_open" => "<button>",
      "prev_tag_close" => "</button>",
      "next_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png' alt='seta-fim'>",
      "next_tag_open" => "<button>",
      "next_tag_close" => "</button>",
      "last_tag_open" => "<button>",
      "last_tag_close" => "</button>",
      "cur_tag_open" => "<button class='active'><a href='#'>",
      "cur_tag_close" => "</a></button>",
      "num_tag_open" => "<button>",
      "num_tag_close" => "</button>"
    );

    $this->pagination->initialize($config);
    $paginacao = $this->pagination->create_links();
    $offset = $this->uri->segment(2)?$this->uri->segment(2):0;

    $id = 'orientador';
    $orientadores = $this->user_model->getUsuario('nm_Usuario', 'ASC', $config['per_page'], $offset, $id);
    
    // $area = $this->prof_model->buscararea();
 
    //carrega areas do Site
    
    $this->load->view('partials/base-topo');
    $this->load->view('orientadores/orientadores', ['orientadores' => $orientadores, 'paginacao' => $paginacao]);
    $this->load->view('partials/base-fim');
  }

  public function adicionar() {

    $areas = $this->al_model->listarAreas();
    $linhas = $this->al_model->listarLinhas();

    $this->load->view('partials/base-topo');
    $this->load->view('orientadores/adicionar',['areas'=>$areas, 'linhas' => $linhas]);
    $this->load->view('partials/base-fim');

    
  // if($this->input->post()){
  //   // var_dump($this->input->post());
  //   // die();
        
  //   $dados['nm_Usuario'] = $this->input->post('nome');
    

  //   if ($this->cpf->validaCPF($this->input->post('cpf'))){
  //     $dados['ds_Cpf'] = $this->input->post('cpf');
  //   } 
  //   else 
  //   {
  //     $this->session->set_flashdata('alert-warning','Cpf Invalido');
      
  //   }

  //   $dados['ds_Email'] = $this->input->post('email');
  //   $dados['nm_Titulacao'] = $this->input->post('titulacao');
  //   $dados['ds_Celular'] = $this->input->post('celular');
    

  //   if ($this->input->post('senha') === $this->input->post('csenha')) {
  //     $dados['ds_Senha'] = $this->criptografar->cripto($this->input->post('senha'));
  //   } 
  //   else
  //   {
  //   $this->session->set_flashdata('alert-warning', 'Senha não são iguais');
    
  //   }

    
  //     // fim de receber dados via post
  //     $this->form_validation->set_rules("cpf", "CPF", "required");
  //     $this->form_validation->set_rules("nome", "Nome", "required");
  //     $this->form_validation->set_rules("email", "Email", "required");
  
  //     if (!empty($dados["senha"])) {
  //       $this->form_validation->set_rules("senha", "Senha", "required");
  //       $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
  //     }
  
  //     // $this->form_validation->set_rules("lattes", "Lattes", "required");
    
  //     $this->form_validation->set_rules("titulacao", "Titulação", "required");
      
  //     if($this->form_validation->run()){
  //       $dadosOrientador = [
  //         'ds_Cpf' => $this->input->post('cpf'),
  //         'nm_Usuario' => $this->input->post('nome'),
  //         'ds_Email' => $this->input->post('email'),
  //         'ds_Senha' => $this->input->post('senha'),
  //         'ds_Lattes' => $this->input->post('lattes'),
  //         'nm_Titulacao' => $this->input->post('titulacao'),
  //         'ds_Celular' => $this->input->post('celular')
  //       ];

  //       // $this->orientador->inserirUsuario($dadosOrientador);
  //       $id = $this->orientador->getIdUsuario($dadosOrientador['ds_Cpf']);
  //       // var_dump($id);
  //       // die();

  //       $dadosArea = [
  //         'cd_Area' => $this->input->post('area'),
  //         'cd_Usuario' => $id[0]["cd_Usuario"]
  //       ];

  //       $dadosLinha = [
  //         'cd_Usuario' => $id[0]["cd_Usuario"],
  //         'cd_Linha' => $this->input->post('linha'),
  //       ];

  //       $dadosNivel = [
  //         'cd_Usuario' => $id[0]["cd_Usuario"],
  //         'cd_Nivel' => 2,
  //       ];
  //       $this->orientador->inserirArea($dadosArea);
  //       $this->orientador->inserirLinha($dadosLinha);
  //       $this->orientador->inserirNivel($dadosNivel);

  //       redirect(base_url('orientadores'));


  //     }else{

  //     $this->session->set_flashdata('alert-warning', 'Você não prencheu os campos direito');
  //     redirect('administradores');

  //     }
   
  //   }




    if($this->input->post()){
      

    
      $dados['nm_Usuario'] = $this->input->post('nome');
      

      if ($this->cpf->validaCPF($this->input->post('cpf'))){
        $dados['ds_Cpf'] = $this->input->post('cpf');
      } 
      else 
      {
        $this->session->set_flashdata('alert-warning','Cpf Invalido');
        
      }

      $dados['ds_Email'] = $this->input->post('email');
      $dados['nm_Titulacao'] = $this->input->post('titulacao');
      $dados['ds_Celular'] = $this->input->post('celular');
      

      if ($this->input->post('senha') === $this->input->post('csenha')) {
        $dados['ds_Senha'] = $this->criptografar->cripto($this->input->post('senha'));
      } 
      else
      {
      $this->session->set_flashdata('alert-warning', 'Senha não são iguais');
      
      }

      
        // fim de receber dados via post
        $this->form_validation->set_rules("cpf", "CPF", "required");
        $this->form_validation->set_rules("nome", "Nome", "required");
        $this->form_validation->set_rules("email", "Email", "required");
    
        if (!empty($dados["senha"])) {
          $this->form_validation->set_rules("senha", "Senha", "required");
          $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
        }
    
        // $this->form_validation->set_rules("lattes", "Lattes", "required");
      
        $this->form_validation->set_rules("titulacao", "Titulação", "required");
        
        if($this->form_validation->run()){
    
        //verifica o form validation
        $this->user_model->InserirProfessor($dados);
        $cd_Usuario = $this->prof_model->getIdUsuario($dados['ds_Cpf']);
      
      
    
        //receber dados sobre a area de pesquisa via post
        $area['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
        $area['cd_Area']  = $this->input->post('area');
        //fim area post

        //receber dados sobre a linha de pesquisa via post
        $linha['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
        $linha['cd_Linha'] = $this->input->post('linha');
        //fim area linha de pesquisa


        //Receber dados do tipo de acesso/nivel via post
        $nivel = [];
        $this->input->post('acesso1')? array_push($nivel, $this->input->post('acesso1')) : null;
        $this->input->post('acesso2')? array_push($nivel, $this->input->post('acesso2')) : null;
        $this->input->post('acesso3')? array_push($nivel, $this->input->post('acesso3')) : null;
        foreach ($nivel as $n) {
        $cd_Nivel = $this->prof_model->getIdNivel($n);
        $acesso['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
        $acesso['cd_Nivel'] = $cd_Nivel[0]['cd_Nivel'];
        //inserir nivel ou acesso
        $this->user_model->inserirNivel($acesso);
        //fim recerber dados nivel/acesso
        }
        $this->user_model->inserirProfessor($dados);
        //Inserir Area e Linha de Pesquisa
        $this->user_model->inserirArea($area);
        $this->user_model->inserirLinha($linha);
          //Mensagem de sucesso 
        $this->session->set_flashdata('alert-success', 'Usuário cadastrado com sucesso');
        redirect('orientadores');  
    
    }
    else{

      $this->session->set_flashdata('alert-warning', 'Você não prencheu os campos direito');


    }
  }
  
  }

  public function editar($id = null) {
 
    $areas = $this->al_model->listarAreas();
    $linhas = $this->al_model->listarLinhas();
    
    $dados = $this->prof_model->buscar($id);
  
    $acesso =$this->prof_model->buscaracesso($id);
    $area = $this->prof_model->buscararea($id);
    $linha = $this->prof_model->buscarlinha($id);
    
    
    $this->load->view('partials/base-topo');
    $this->load->view('avaliadores/editar',['dados'=> $dados, 'areas' => $areas, 'linhas' => $linhas,'acesso' => $acesso,'area' => $area, 'linha' => $linha]);
    $this->load->view('partials/base-fim'); 



    $areas = $this->al_model->listarAreas();
    $linhas = $this->al_model->listarLinhas();
    
    $dados = $this->prof_model->buscar($id);
  
    $acesso =$this->prof_model->buscaracesso($id);
    $area = $this->prof_model->buscararea($id);
    $linha = $this->prof_model->buscarlinha($id);


    if($this->input->post()){
    
      $dados['nm_Usuario'] = $this->input->post('nome');
      

    if ($this->cpf->validaCPF($this->input->post('cpf'))){
      $dados['ds_Cpf'] = $this->input->post('cpf');
    } 
    else 
    {
      $this->session->set_flashdata('alert-warning','Cpf Invalido');
      
    }

    $dados['ds_Email'] = $this->input->post('email');
    $dados['nm_Titulacao'] = $this->input->post('titulacao');
    $dados['ds_Celular'] = $this->input->post('celular');
    

    if ($this->input->post('senha') === $this->input->post('csenha')) {
      $dados['ds_Senha'] = $this->criptografar->cripto($this->input->post('senha'));
    } 
    else
    {
    $this->session->set_flashdata('alert-warning', 'Senha não são iguais');
    
    }

    
      // fim de receber dados via post
      $this->form_validation->set_rules("cpf", "CPF", "required");
      $this->form_validation->set_rules("nome", "Nome", "required");
      $this->form_validation->set_rules("email", "Email", "required");
  
      if (!empty($dados["senha"])) {
        $this->form_validation->set_rules("senha", "Senha", "required");
        $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
      }
  
      // $this->form_validation->set_rules("lattes", "Lattes", "required");
    
      $this->form_validation->set_rules("titulacao", "Titulação", "required");
      
      if($this->form_validation->run()){
  
      //verifica o form validation
      $this->prof_model->InserirProfessor($dados);
      $cd_Usuario = $this->prof_model->getIdUsuario($dados['ds_Cpf']);
    
    
  
      //receber dados sobre a area de pesquisa via post
      $area['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
      $area['cd_Area']  = $this->input->post('area');
      //fim area post

      //receber dados sobre a linha de pesquisa via post
      $linha['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
      $linha['cd_Linha'] = $this->input->post('linha');
      //fim area linha de pesquisa


      //Receber dados do tipo de acesso/nivel via post
      $nivel = [];
      $this->input->post('acesso1')? array_push($nivel, $this->input->post('acesso1')) : null;
      $this->input->post('acesso2')? array_push($nivel, $this->input->post('acesso2')) : null;
      $this->input->post('acesso3')? array_push($nivel, $this->input->post('acesso3')) : null;
      foreach ($nivel as $n) {
      $cd_Nivel = $this->prof_model->getIdNivel($n);
      $acesso['cd_Usuario']  = $cd_Usuario[0]['cd_Usuario'];
      $acesso['cd_Nivel'] = $cd_Nivel[0]['cd_Nivel'];
      //inserir nivel ou acesso
        
      $this->user_model->deleteUsuario_Nivel($id);
      $this->user_model->deleteUsuario_Linha($id);
      $this->user_model->deleteUsuario_Area($id);
      $this->user_model->delete($id);
      $this->user_model->inserirNivel($acesso);

      //fim recerber dados nivel/acesso
      }
      $this->prof_model->inserirProfessor($dados);
      //Inserir Area e Linha de Pesquisa
      $this->prof_model->inserirArea($area);
      $this->prof_model->inserirLinha($linha);
        //Mensagem de sucesso 
      $this->session->set_flashdata('alert-success', 'Usuário atualizado com sucesso');
      redirect('avaliadores');  
  
  }

    } 
  }

   //Funcao Deletar
  public function deletar($id) {
    if(!$id) return redirect(avaliadores);
    else{
      
      $this->user_model->deleteUsuario_Nivel($id);
      $this->user_model->deleteUsuario_Linha($id);
      $this->user_model->deleteUsuario_Area($id);
      $this->user_model->delete($id);

      $this->session->set_flashdata('alert-success','Administrador excluido  com sucesso');
      return redirect('avaliadores');
    } 
  }
  //Fim da Funcao deletar  
  public function validar($dados) {
    
    //Validacao de Formulario
    $this->form_validation->set_rules("cpf", "CPF", "required");
    $this->form_validation->set_rules("nome", "Nome", "required");
    $this->form_validation->set_rules("email", "Email", "required");
  
    if (!empty($dados["senha"])) {
      $this->form_validation->set_rules("senha", "Senha", "required");
      $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
    }
  
    $this->form_validation->set_rules("lattes", "Lattes", "required");
    
    $this->form_validation->set_rules("titulacao", "Titulação", "required");
    // $this->form_validation->set_rules('celular', 'Celular', array('required'));
    
    //Fim Validacao de Formulario
    return $this->form_validation->run();
    }
  //Fim de Validacao

}