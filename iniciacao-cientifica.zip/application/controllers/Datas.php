<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datas extends Controle_acesso {
	public function __construct() {
		parent::__construct();
		$this->verificarPermissoes(['master']);
		$this->load->library('form_validation');
		$this->load->library('Cpf');
		$this->load->library('Criptografar');
		$this->load->model('datas_model');
	}

	public function index() {
		$datas = $this->datas_model->all();
		$this->load->view('datas/datas', ['datas' => $datas]);
	}
	
	public function salvar() {
		$dados['dt_Inicial'] = $this->input->post('data-inicial');
		$dados['dt_Final'] = $this->input->post('data-final');
		$dados['cd_Evento'] = $this->input->post('evento');
		
		if ($this->datas_model->save($dados)) {
			echo 'Salvou com sucesso';
		}
		else {
			echo 'erro ao salvar!';
		}
	}
	
	public function eventos($data = null) {
		$eventos = $this->datas_model->getEventos($data);
		var_dump($eventos);
	}
	

	public function eventoNow($evento){
		$flag = $this->datas_model->verificaEventoData($evento);
		var_dump($flag);
	}
}