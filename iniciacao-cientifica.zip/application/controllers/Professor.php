<?php
defined("BASEPATH") OR exit("No direct script access allowed");

class Professor extends CI_Controller {
  # Diretório base existente em `views`
  private $diretorio = "professores";

	public function __construct() {
    parent::__construct();
    $this->load->model('professor_model', 'professor');
  }

  public function index() {
    $view = "$this->diretorio/professores";
    $professores = $this->professor->listar();
    
    return $this->load->view($view, [
      "professores" => $professores
    ]);
  }
  
  public function cadastrar() {
    $form = $this->input->post();
    return $form ? $this->salvar($form) : $this->form();
  }

  public function editar($id) {
    $professor = $this->professor->buscar($id);

    if (empty($professor)) {
      # Redirect momentâneo. Deve ser modificado.
      return $this->load->view('welcome_message');
    }
    
    $form = $this->input->post();

    return $form
      ? $this->salvar($form, true, $id)
      : $this->form(true, $professor, null, $id);
  }
  
  /**
   * Centraliza ações de cadastro e atualização
   * das informações pertinentes ao usuário Professor.
   * 
   * @param Array $form     | Dados da requesição (post|get) 
   * @param Boolean $editar | Indicador do tipo de ação
   * @param Integer $id     | Valor contendo o #id do professor
   * 
   * @return View
  */
  public function salvar($form, $editar = false, $id = null) {
    if (!$this->validar($editar, $form)) {
      return $this->form($editar, $form, [
        "neutro" => "Preencha o formulário corretamente", 
        "erro"   => validation_errors()
      ], $id);
    }
    
    $erros = $this->verificarValores($form, $editar, $id);
    
    if (!empty($erros)) {
      return $this->form($editar, $form, ["erro" => $erros], $id);
    }

    $salvo = $editar
      ? $this->professor->editar($form, $id)
      : $this->professor->cadastrar($form);

    if ($salvo) {
      $redirect = $editar ? "editar/$id" : "cadastrar";
      $this->session->set_flashdata("alert-success", "Sucesso ao salvar o professor");

      return redirect(base_url("professores/$redirect"));
    }
  }

  public function validar($editar = false, $form) {
    $this->load->library('form_validation');

    $this->form_validation->set_rules("cpf", "CPF", "required");
    $this->form_validation->set_rules("nome", "Nome", "required");
    $this->form_validation->set_rules("email", "Email", "required");

    if (!$editar || !empty($form["senha"])) {
      $this->form_validation->set_rules("senha", "Senha", "required");
      $this->form_validation->set_rules("confirmacao-senha", "Confirmação de Senha", "required|matches[senha]");
    }

    $this->form_validation->set_rules("lattes", "Lattes", "required");
    $this->form_validation->set_rules("celular", "Celular", "required");
    $this->form_validation->set_rules("titulacao", "Titulação", "required");

    return $this->form_validation->run();
  }

  /**
   * Verificar valores que não podem ser duplicados
   * 
   * @param Array $form
   * @param Boolean $editar
   * 
   * @return Array
   */
  public function verificarValores($form, $editar, $id) {
    # Valores a serem verificados
    $colunas = [
      "cpf"   => "ds_Cpf",
      "email" => "ds_Email",
      "nome"  => "nm_Usuario"
    ];

    $erros = [];

    foreach ($colunas as $coluna) {
      $valor    = array_keys($colunas, $coluna)[0];
      $registro = $this->professor->existeRegistro($coluna, $form[$valor], $id);
    
      if ($registro) {
        $erros[] = "<p>O valor $valor já está em uso</p>\n";
      }
    }

    return count($erros) ? implode('\n', $erros) : null;
  }

  /**
   * Realiza as configurações necessárias a um
   * determinado formulário que será retornado.
   * 
   * @param Boolean $editar  | Determina a view
   * @param Array $dados     | Dados dos inputs
   * @param Array $mensagens | Balões de feedback
   * @param Integer $id      | ID do professor (p/ edição)
   * 
   * @return View
  */
  public function form($editar = false, $dados = null, $mensagens = null, $id = null) {
    $acao = $editar ? "editar" : "cadastrar";
    $caminho = "$this->diretorio/$acao";

    $action = $editar && !empty($id) ? "/$id" : null;
    $action = $caminho . $action;

    return $this->load->view("default/form", [
      "form"      => $dados,
      "action"    => $action,
      "view"      => $caminho,
      "mensagens" => $mensagens,
    ]);
  }
}