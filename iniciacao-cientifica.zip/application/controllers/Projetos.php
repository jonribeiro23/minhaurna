<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Projetos extends Controle_acesso {
  public function __construct() {
    parent::__construct();
    $this->verificarPermissoes(['master', 'orientador', 'avaliador']);
    $this->load->library('form_validation');
    $this->load->library('pagination');
    $this->load->helper('form');
    $this->load->model('projetos_model');
    $this->load->model('datas_model');
    $this->load->model('autor_model');
  }

  public function index() {
    
    //Configuração de diferentes variáveis dependendo da tela
    $telas_config = [
      'projetos-avaliadores' => [
        'view' => 'projetos/projetos'
      ],
      'projetos-pendentes' => [
        'view' => 'projetos/listar_pendente'
      ],
      'projetos-avaliar' => [
        'view' => 'projetos/listar_avaliar'
      ],
      'projetos-ressalva' => [
        'view' => 'projetos/listar_ressalva'
      ],
      'projetos-recusados' => [
        'view' => 'projetos/listar_recusados'
      ],
      'projetos-concluido' => [
        'view' => 'projetos/listar_concluido'
      ],
      'projetos-proprios-andamento' => [
        'view' => 'projetos/projeto-proprio-andamento'
      ],
      'projetos-proprios-concluido' => [
        'view' => 'projetos-proprios/concluido-semlink'
      ]
    ];

    //Pega a informação da primeira parte da url Ex.: "projetos"/pendentes
    $uri1 = $this->uri->segment(1);
    //Pega a informação da segunda parte da url Ex.: projetos/"pendentes"
    $uri2 = $this->uri->segment(2);
    //Junta os dois com um hífen Ex.: "projetos-pendentes"
    $tela = $uri1 . '-' . $uri2;
   
    //Checa se a junção não existe na lista de possibilidades
    if (!array_key_exists($tela, $telas_config)) {
      //Redireciona para um página "padrão" dependendo da primeira parte da url
      //caso a segunda não exista na lista
      switch($uri1){
        case 'projetos':
          return redirect('projetos/avaliadores');
          break;
        case 'projetos-proprios':
          return redirect('projetos-proprios/andamento');
          break;
        default:
          return redirect('projetos/avaliadores');
          break;
      }
    }
    

    //CONFIGURA PAGINAÇÃO
    //url que será utilizada (vai depender das URIs)
    $pag_config['base_url'] = base_url("$uri1/$uri2/listar");
    //total de registros (incompleto)
    $pag_config['total_rows'] = $this->projetos_model->contar_projetos();
    //resultados por página
    $pag_config['per_page'] = 5;
    //usar número da página na url em vez de índice
    $pag_config['use_page_numbers'] = true;
    //mantem possíveis parêmetros da url
    $pag_config['reuse_query_string'] = true;
    
    //ESTILO PAGINAÇÃO
    //conteúdo do botão de "primeira página"
    $pag_config['first_link'] = '<img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-left.png" alt="seta-inicio">';
    //$pag_config['first_url'] = base_url('$uri1/$uri2');
    //conteúdo do botão de "última página"
    $pag_config['last_link'] = '<img src="https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png" alt="seta-fim">';
    //desabilita o botão de "próxima página"
    $pag_config['next_link'] = false;
    //desabilita o botão de "página anterior"
    $pag_config['prev_link'] = false;
    //tags do "botão" da página atual
    $pag_config['cur_tag_open'] = '<a class="active button">';
    $pag_config['cur_tag_close'] = '</a>';
    //classes adicionadas aos botões de páginas (são todos sempre <a>)
    $pag_config['attributes'] = array('class' => 'button');

    //inicializa a paginação
    $this->pagination->initialize($pag_config);

    //pega o índice baseado no número da página na url (x5 pq são 5 por página)
    $pagina = ($this->uri->segment(4)) ? ($this->uri->segment(4)-1)*5 : 0;
    //lista os projetos (incompleto)
    $projetos = $this->projetos_model->listar_pagina($pagina);
    
    $this->load->view('partials/base-topo');
    //chama a view correta baseado nas variáveis configuradas
    $this->load->view($telas_config[$tela]['view'], ['projetos' => $projetos]);
    $this->load->view('partials/base-fim');
  }

  public function visualizar($id) {

    //Pega a informação da primeira parte da url Ex.: "projetos"/ressalva/ver/6
    $uri1 = $this->uri->segment(1);
    //Pega a informação da terceira parte da url Ex.: projetos/"ressalva"/ver/6
    $uri2 = $this->uri->segment(2);
    //Junta os dois com um hífen Ex.: "projetos-ressalva"
    $tela = $uri1 . '-' . $uri2;

    if (empty($id)) return redirect("$uri1/$uri2");

    $projeto = $this->projetos_model->get_projeto($id);

    if (empty($projeto)) {
      //$this->session->set_flashdata('alert-warning', 'Projeto não encontrado');
      //return redirect("$uri1/$uri2");
    }

    //Configuração de diferentes variáveis dependendo da tela
    $telas_config = [
      'projetos-avaliadores' => [
        'view' => 'projetos/definir-avali-visualizar'
      ],
      'projetos-ressalva' => [
        'view' => 'projetos/ressalva-visualizar'
      ],
      'projetos-recusados' => [
        'view' => 'projetos/recusados-visualizar'
      ],
      'projetos-concluido' => [
        'view' => 'projetos/concluido-visualizar'
      ]
    ];
   
    //Checa se a junção não existe na lista de possibilidades
    if (!array_key_exists($tela, $telas_config)) {
      return redirect("$uri1/$uri2");
    }

    $this->load->view('partials/base-topo');
    //chama a view correta baseado nas variáveis configuradas
    $this->load->view($telas_config[$tela]['view'], ['projeto' => $projeto]);
    $this->load->view('partials/base-fim');

  }

  public function index_proprios() {
    $this->load->view('partials/base-topo');
    $this->load->view('projetos/projeto-proprio-andamento');
    $this->load->view('partials/base-fim');
  }

  public function teste(){
    $ids = $this->autor_model->getIdAutores($this->usuario['id_usuario']);
    $autores = [];
    foreach ($ids as $id) {
      $r = $this->autor_model->getAutor($id['cd_Autor']);
      array_push($autores, $r);
    }
    $this->load->view('partials/base-topo');
    $this->load->view('projetos/adicionar', ['autores' => $autores]);
    $this->load->view('partials/base-fim');
  }

  public function adicionar() {
    $ids = $this->autor_model->getIdAutores($this->usuario['id_usuario']);
    $autores = [];
    foreach ($ids as $id) {
      $r = $this->autor_model->getAutor($id['cd_Autor']);
      array_push($autores, $r);
    }
    $this->load->view('partials/base-topo');
    $this->load->view('projetos/adicionar', ['autores' => $autores]);
    $this->load->view('partials/base-fim');
  }
  
  public function editar($id){
    $projeto = $this->projetos_model->get_projeto($id);
    if (!$projeto) return redirect('projetos');

    $this->load->view('partials/base-topo');
    $this->load->view('projetos/editar', ['projeto' => $projeto, 'id' => $id]);
    $this->load->view('partials/base-fim');
  }

  public function salvar($editar = false) {
    $editar = $this->input->post('editar');

    $this->form_validation->set_rules('titulo', 'Título', 'required');
    $this->form_validation->set_rules('autor', 'Autor', 'required');
    $this->form_validation->set_rules('linha', 'Linha de pesquisa', 'required');

    if ($this->form_validation->run()) {
      $form = $this->input->post();

      $upload_return = $this->upload_projeto();
      $projeto = ['nm_Titulo' => $form['titulo'],
                  'ds_Url'    => $upload_return['secure_url']];

      $editar ?
        $this->atualizar_projeto($projeto, $form['id']) :
        $this->inserir_projeto($projeto);
    }
    else {
      redirect('projetos/adicionar');
    }
  }
  
  public function deletar($id = false) {
    if(!$id) return redirect(projetos);

    if ($this->projetos_model->deletar($id)) {
      $this->session->set_flashdata(
        'alert-success',
        'Projeto deletado com sucesso'
      );
      return redirect('projetos');
    } else {
      $this->session->set_flashdata(
        'alert-danger',
        'Erro ao deletar projeto'
      );
      return redirect('projetos');
    }
  }

  private function inserir_projeto($projeto) {
    if ($this->projetos_model->inserir($projeto)) {
      $this->session->set_flashdata(
        'alert-success',
        'Projeto cadastrado com sucesso.'
      );
      return redirect('projetos');
    }
    else {
      $this->session->set_flashdata(
        'alert-danger',
        'Erro ao cadastrar projeto'
      );
      return redirect('projetos/adicionar');
    }
  }

  private function atualizar_projeto($projeto, $id) {
    if ($this->projetos_model->atualizar($projeto, $id)) {
      $this->session->set_flashdata(
        'alert-success',
        'Projeto atualizado com sucesso.'
      );
      return redirect('projetos');
    }
    else {
      $this->session->set_flashdata(
        'alert-danger',
        'Erro ao atualizar projeto'
      );
      return redirect('projetos/editar');
    }
  }

  private function upload_projeto()
  { 
    $this->load->library('Uploader');
    return $this->uploader->upload($_FILES['projeto']);
  }
  
  //Apenas para visualizacao do front
  public function ressalva(){
    $this->load->view('partials/base-topo');
    $this->load->view('projetos/visualizar-ressalva');
    $this->load->view('partials/base-fim');
  }

  //Apenas para visualizacao do front
  public function avaliar($id = null) {
    $this->load->view('partials/base-topo');
    empty($id) ? $this->load->view('projetos/listar_avaliar') : $this->load->view('projetos/avaliar');
    $this->load->view('partials/base-fim');
  }


}
