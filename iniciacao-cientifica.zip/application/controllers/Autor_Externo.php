<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autor_Externo extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->library('Cpf');
		$this->load->library('Criptografar');
		$this->load->model('autor_externo_model', 'autor');
		$this->load->model('datas_model', 'datas');
	}

	public function index() {
		$this->load->view('aluno-externo/pagina-inicial');
	}
	
	public function login() {
		$this->load->view('aluno-externo/login/login');
	}
	
	public function autenticar() {
		$email = $this->input->post('login');
		$senha = $this->criptografar->cripto($this->input->post('password'));
		
		//login para testar felipe@gmail.com
		//senha 12345678
		
		if (empty($email) || empty($senha)) {
			$this->session->set_flashdata('alert-warning', 'Preencha os campos corretamente');
			return redirect('Autor_Externo/login');
		}
		else{
			if (!$this->autor->logar($senha, $email)) {
				$this->session->set_flashdata('alert-warning', 'Senha ou email invalidos');
				return redirect('Autor_Externo/login');
			}
			else{
				$this->load->library('session');
				$this->session->userdata('logado');
		
				redirect('projetos');
			}
		}
	}
	
	public function cadastro() {
		$this->load->view('aluno-externo/cadastro/cadastro');
	}
	

	public function adicionar(){

	   if($this->validar($this->input->post('cpf'), $this->input->post('email'))){
			$this->form_validation->set_rules('nome', 'NOME', array('required', 'min_length[3]'));
			$this->form_validation->set_rules('email', 'EMAIL', array('required'));
			$this->form_validation->set_rules('cpf', 'CPF', array('required'));
			$this->form_validation->set_rules('senha', 'SENHA', array('required', 'min_length[8]'));

		   
			if ($this->form_validation->run()) {
				$dados['nm_Autor'] = $this->input->post('nome');
				$dados['ds_Cpf'] = $this->criptografar->cripto($this->input->post('cpf'));
				$dados['ds_Email'] = $this->input->post('email');
				$dados['ds_Senha'] = $this->criptografar->cripto($this->input->post('senha'));
				$dados['nm_Instituicao'] = $this->input->post('instituicao');
				$dados['nm_Curso'] = 'Qualquer';
				$dados['ds_Lattes'] = 'https://pt.stackoverflow.com/questions/242092/melhor-maneira-de-usar-criptografia-aes';
				
				$this->autor->inserir($dados);
				$this->session->set_flashdata('alert-success', 'Usuário cadastrado com sucesso');
			}
			else {
				$this->session->set_flashdata('alert-warning', 'Erro de validação');
				redirect(base_url('externo/cadastro'));
			}
		}
		else {
			redirect(base_url('externo/cadastro'));
	  }
	}
	
	public function validar($cpf, $email) {
		$usu = $this->criptografar->cripto($cpf);
		$cpf = $this->cpf->validaCPF($cpf);
		$usuario = $this->autor->getUsuario($usu);
		$email = $this->autor->getEmail($email);
		
		if ($cpf && !$usuario && !$email) {
			return true;
		}
		else {
			if (!$cpf) {
				$this->session->set_flashdata('alert-warning', 'CPF inválido.');
			}

			if ($usuario) {
				$this->session->set_flashdata('alert-warning', 'Usuário já cadastrado');
			}

			if ($email) {
				$this->session->set_flashdata('alert-warning', 'Email já cadastrado');
			}
	
			return false;
		}
	}
}