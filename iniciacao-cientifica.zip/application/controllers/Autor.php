<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Autor extends Controle_acesso {
	public function __construct() {
		parent::__construct();
		$this->verificarPermissoes(['master', 'orientador']);
		$this->load->model('Autor_model', 'autor');
		$this->load->model('Areas_Linhas_model', 'al');
		$this->load->library('Criptografar');
		$this->load->library('form_validation');
	}
	
	public function listar($inicio = 0) {

		$config = array(
			"base_url" => base_url('autores'),
			"per_page" => 5,
			"num_links" => 3,
			"uri_segment" => 2,
			"total_rows" => $this->autor->countAll(),
			"full_tag_open" => "<div class='buttons'>",
			"full_tag_close" => "</div>",
			"first_link" => FALSE,
			"last_link" => FALSE,
			"first_tag_open" => "<button>",
			"first_tag_close" => "</button>",
			"prev_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-left.png' alt='seta-fim'>",
			"prev_tag_open" => "<button>",
			"prev_tag_close" => "</button>",
			"next_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png' alt='seta-fim'>",
			"next_tag_open" => "<button>",
			"next_tag_close" => "</button>",
			"last_tag_open" => "<button>",
			"last_tag_close" => "</button>",
			"cur_tag_open" => "<button class='active'><a href='#'>",
			"cur_tag_close" => "</a></button>",
			"num_tag_open" => "<button>",
			"num_tag_close" => "</button>"
		);

		$this->pagination->initialize($config);
		$paginacao = $this->pagination->create_links();
		$offset = $this->uri->segment(2)?$this->uri->segment(2):0;

		$autores = $this->autor->getAutores('nm_Autor', 'ASC', $config['per_page'], $offset);
		$this->load->view('partials/base-topo');
		$this->load->view('autores/autores', ['autores' => $autores, 'paginacao' => $paginacao]);
		$this->load->view('partials/base-fim');
	}

	public function adicionar() {
		$linhas = $this->al->listarLinhas();
		$cursos = $this->autor->getCursos();

		$this->load->view('partials/base-topo');
		$this->load->view('autores/adicionar', ['linhas' => $linhas, 'cursos' => $cursos]);
		$this->load->view('partials/base-fim');
	}

	public function salvar(){

		$editar = $this->uri->segment(3);

		if($editar==null && $this->jaExiste($this->input->post('cpf'))){
			$this->session->set_flashdata('alert-warning', 'Usuário já cadastrado');
			redirect(base_url('autores'));
		}else{
			$this->form_validation->set_rules('nome','NOME', array('required', 'min_length[5]'));
			$this->form_validation->set_rules('cpf', 'CPF', array('required'));
			$this->form_validation->set_rules('email', 'EMAIL', array('required'));
			$this->form_validation->set_rules('curso', 'CURSO', array('required'));

			if ($this->form_validation->run()) {
				$autor['nm_Autor'] = $this->input->post('nome');
				$autor['ds_Cpf'] = $this->input->post('cpf');
				$autor['ds_Email'] = $this->input->post('email');
				$autor['ds_Lattes'] = $this->input->post('lattes')?$this->input->post('lattes'):null;
				$autor['nm_Curso'] = $this->input->post('curso');


				if ($editar) {
					$this->autor->editar($editar, $autor);
					$this->session->set_flashdata('alert-success', 'Usuário cadastrado com sucesso');
					redirect(base_url('autores'));
				}

				if ($editar==null && $this->autor->salvar($autor)) {
					$cd_autor = $this->autor->getId($autor['ds_Cpf']);
					
					$dados = [
						'cd_Orientador' => $this->usuario['id_usuario'],
						'cd_Autor' => $cd_autor[0]->cd_Autor
					];

					$this->autor->relacaoOrientadorAutor($dados);
					$this->session->set_flashdata('alert-success', 'Usuário cadastrado com sucesso');
					redirect(base_url('autores'));
				}else{
					$this->session->set_flashdata('alert-warning', 'Erro ao cadastrar!');
					redirect(base_url('autores'));
				}
			}else{
				$this->session->set_flashdata('alert-warning', 'Preencha todos os campos!');
				redirect(base_url('autores/adicionar'));
			}
		}

	}
	
	public function editar() {
		$id = $this->uri->segment(3);
		$autor = $this->autor->getAutor($id);
		$cursos = $this->autor->getCursos();

		$this->load->view('partials/base-topo');
		$this->load->view('autores/editar', ['autor' => $autor[0], 'cursos' => $cursos]);
		$this->load->view('partials/base-fim');
	}

	public function deletar(){
		$id = $this->uri->segment(3);
		if ($this->autor->deletar($id)) {
			$this->session->set_flashdata('alert-success', 'Usuário deletado com sucesso');
			redirect(base_url('autores'));
		}else{
			$this->session->set_flashdata('alert-warning', 'Erro ao deletar!');
			redirect(base_url('autores'));
		}
	}

	public function teste(){
		echo "<pre>";
		$ids = $this->autor->getIdAutores($this->usuario['id_usuario']);
		$autores = [];
		foreach ($ids as $id) {
			$r = $this->autor->getAutor($id['cd_Autor']);
			array_push($autores, $r);
		}
		var_dump($autores);
	}

	public function preencheForm(){
		$cpf = $this->input->post('query');
		// echo $cpf;
		$data = $this->autor->getAluno($cpf);
		echo json_encode($data);
	}

	public function jaExiste($cpf){
		if ($this->autor->verifica($cpf)) {
			return true;
		}
	}

	public function todos_autores(){
		$config = array(
			"base_url" => base_url('autores'),
			"per_page" => 5,
			"num_links" => 3,
			"uri_segment" => 2,
			"total_rows" => $this->autor->countAll(),
			"full_tag_open" => "<div class='buttons'>",
			"full_tag_close" => "</div>",
			"first_link" => FALSE,
			"last_link" => FALSE,
			"first_tag_open" => "<button>",
			"first_tag_close" => "</button>",
			"prev_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-left.png' alt='seta-fim'>",
			"prev_tag_open" => "<button>",
			"prev_tag_close" => "</button>",
			"next_link" => "<img src='https://img.icons8.com/ios-glyphs/15/733DBF/long-arrow-right.png' alt='seta-fim'>",
			"next_tag_open" => "<button>",
			"next_tag_close" => "</button>",
			"last_tag_open" => "<button>",
			"last_tag_close" => "</button>",
			"cur_tag_open" => "<button class='active'><a href='#'>",
			"cur_tag_close" => "</a></button>",
			"num_tag_open" => "<button>",
			"num_tag_close" => "</button>"
		);

		$this->pagination->initialize($config);
		$paginacao = $this->pagination->create_links();
		$offset = $this->uri->segment(2)?$this->uri->segment(2):0;

		$autores = $this->autor->getAutores('nm_Autor', 'ASC', $config['per_page'], $offset);

		$this->load->view('partials/base-topo');
		$this->load->view('autores/todos-autores', ['autores' => $autores, 'paginacao' => $paginacao]);
		$this->load->view('partials/base-fim');
	}
	
	
}