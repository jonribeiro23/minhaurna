<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teste extends CI_Controller {
	public function __construct() {
		parent::__construct();
	}

	public function teste() {
		echo("Teste - Equipe Web");
	}

	public function getLinhas($area = null){
		$this->load->model('Areas_Linhas_model','al');
		var_dump($this->al->listarLinhas($area));
	}
}