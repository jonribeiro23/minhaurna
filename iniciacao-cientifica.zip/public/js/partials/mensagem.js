$(document).ready(main);

var idInterval;

function main() {
    $('.alerta-fechar').click(function() {
        var parente = $(this).parent().parent();
        
        parente.removeClass('fadeInRightBig');
        parente.addClass('fadeOutRightBig');
        
        idInterval = setInterval(verificarAlertas, 500);
    });
    
}

function verificarAlertas() {
    ($('.alertas .fadeInRightBig').length === 0) ?
        $('.alertas').addClass('alertas-fechados'):
        $('.alertas').removeClass('alertas-fechados');
    
    clearInterval(idInterval);
}