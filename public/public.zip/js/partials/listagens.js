/* accordion */

 $(document).ready(function(){
		$(".fa-info-circle").click(function(){
		    $(this).next().toggle("slow");
		});
 });	   



/* modal */

$(document).ready(function() { 
 $('.modal-open, .modal-close').on("click", function() {
  $('.modal').fadeToggle();
   return false;
 });
});	

/* seleção checkbox */

	total = 0;
	function Avaliador(objeto)
	{	
	if (objeto.checked)
		total++
	else
		total--


	if (total >2)	
	{
		objeto.checked = false;
		total--
	}
	}